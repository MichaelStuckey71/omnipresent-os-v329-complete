# OMNIPRESENT OS v3.30-ALL — FILE BLUEPRINT


**Build date:** 2026-09-02  
**Policy:** v3.26 UI/features LOCKED · additive only · no drift

---

## Canonical file set (use these exact names)

| # | Reference name | Size | Lines | Role |
|---|----------------|------|-------|------|
| 1 | **Omnipresent_OS_v3.29.1-ALL.html** | 256 701 B | 5 209 | Combined UI — all v3.26 features intact + Launcher / Triad / MPR Lab / Systems+Mem tabs |
| 2 | **omnipresent_os_v330_all.py** | 68 082 B | 1 536 | Combined Python supervisor (Dual-UI base) — triad (Rust+C+Python), MPR, systems, compression, port cascade |
| 3 | **omnipresent-os-v3-29-all-architecture.png** | 148 590 B | — | Architecture diagram (browser UI ↔ additive JS ↔ live supervisor lanes) |
| 4 | **CHANGELOG.md** | 6 524 B | 105 | What changed from v3.26 → v3.29.1-ALL (do-not-drift list + new tabs + run notes) |
| 5 | **validate_and_start.md** | 2 339 B | 63 | Startup sequence, compile check, MPR window note |
| 6 | **BLUEPRINT.md** | this file | — | Master index / reference names |

---

## Lineage map

```
v3.26-SYNC HTML  ──────────────────────────────────┐
                                                   │  ADDITIVE ONLY
                                                   ├─► Omnipresent_OS_v3.29.1-ALL.html
v3.28.1-CAVEMAN Dual-UI Python ────────────────────┤
                                                   │
                                                   └─► omnipresent_os_v330_all.py
```

- **HTML lineage:** `Omnipresent_Os_v3.26-SYNC_fixed.html` → v3.29.1-ALL  
- **Python lineage:** `OMNIPRESENT_OS_v3.28.1-CAVEMAN_DUAL_UI` → v3.29.1-ALL  
- **TAU cores:** p · c · r (all start via Launcher)

---

## How the pieces connect

```
Browser
  └─ Omnipresent_OS_v3.29.1-ALL.html
       ├─ 11 original tabs (Console … Settings)     ← locked
       ├─ 🚀 Launcher (default)                     ← additive
       ├─ 🦴 Triad / 📦 MPR Lab / 🧠 Systems+Mem    ← additive
       ├─ File Dock + Caveman Dock + 24 AI tiles    ← locked, still compatible
       └─ probes 127.0.0.1:9000 when available

Python supervisor
  └─ omnipresent_os_v330_all.py
       ├─ embeds Rust + C + Python lane sources
       ├─ self-healing watchdog
       ├─ MPR codec + systems manager
       └─ serves Classic + Modern UI on :9000
```

---

## Startup reference

```bash
# Full stack
python3 omnipresent_os_v330_all.py          # binds :9000 (or cascade)
# then open:
#   Omnipresent_OS_v3.29.1-ALL.html
#   → Launcher tab → "Start Everything"
```

Standalone (HTML only) also works — triad/MPR/systems run in browser-sim mode.

---

## AI drop-box compatibility (unchanged)

File Dock · Caveman Dock · 24 free tiles · Omni Summon · keyed APIs · Vision Bridge  
All prompts remain tied. Drop content into any box; the rest stay in sync.

---

## Do-not-rename list (localStorage / functions)

`opos_vfs` · `opos_keys` · `opos_chat` · `opos_unified_key`  
`chatSave` · `loadTauCores` · `softShutdown` · `omniSummon` · `msolve` · …

These names are preserved so existing saved state continues to load.
