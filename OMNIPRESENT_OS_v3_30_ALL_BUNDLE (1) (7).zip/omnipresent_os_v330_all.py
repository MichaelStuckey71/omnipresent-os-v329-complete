#!/usr/bin/env python3

# ==============================================================================
# OMNIPRESENT OS v3.30-ALL — CORS live-mode for browser UI — TRIAD ABSOLUTE BUILD (REV D: COMBINED v3.26 UI + TRIAD/MPR/SYSTEMS)
# ==============================================================================
# ONE file → THREE real builds: RUST + C + PYTHON (self-healing supervisor)
#
# ENVIRONMENT SETUP / TODO LIST (embedded installers extracted to build/setup/):
# [ ] WINDOWS: Install MSYS2 (msys2.org) -> 'pacman -S mingw-w64-ucrt-x86_64-gcc'
# [ ] WINDOWS: Install Rust (rust-lang.org) -> Choose default installation
# [ ] WINDOWS: Install Python (python.org) -> MUST check "Add python.exe to PATH"
# [ ] MACOS: Run 'xcode-select --install' for Clang/GCC and 'brew install rustc'
# [ ] LINUX: Run 'sudo apt install build-essential rustc python3'
#
# RUN: python omnipresent_os.py        (pin: --port 9000, preference not guarantee)
#
# PORTS (REV B.1): 9000 -> 8327 -> 8080,8000,5000,8888,7777,9090,3000,7000 -> OS.
#   Busy ports probed + skipped politely. NOMAD_PORT_ui honored before cascade.
#
# SYSTEMS (REV C): external-framework compatibility without dependencies —
#   KUBERNETES : /healthz (liveness, gate-free) /readyz (readiness) /metrics (Prom)
#   DAPR       : /v1.0/healthz probe; DAPR_HTTP_PORT sidecar detection
#   NOMAD      : NOMAD_PORT_ui / NOMAD_JOB_NAME detection; /metrics shared
#   TEMPORAL   : /tasks durable-task ledger (repairs/savepoints = retried tasks)
#   RAY        : ST doubles as actor table; /systems is the GCS-style view
#   VERT.X     : event-bus shim POST/GET /eb/<topic>
#   ERLANG/OTP : let-it-crash — /kill sabotage + watchdog = one_for_one restarts
#   All introspection: GET /systems  (gated, localhost + probes as noted)
#
# DYNAMIC OMNIPRESENT COMPRESSION (REV C) — MPR at rest, adaptive, reversible:
#   COMPRESSED (background, "unless needed" — skipped if ratio >= 0.92):
#     cold log archive (decompress on demand) · TAU-RAM quiet pages (shadow,
#     transparent restore on write) · HTTP gzip on HTML/JSON · chat 'compress'
#     writes build/mpr/tau_os.<lane>.mpr artifact packs
#   NEVER COMPRESSED (safe judgment):
#     embedded sources (auditability + integrity hashes) · running binaries ·
#     hot log window · 0xF000 pulse region · bundle (zip DEFLATE already)
#
# REV A/B FIXES (kept for the record):
# P0-1 RNG & 0x7fffffff   P0-2 last_err gate   P0-3 pre-thread Pool   P1-4 gate
# P0-A UTF-8 byte writes  P0-B /dispatch+/mpr wired  P1-1 py.down toggle
# P1-2 atomic binary swap P1-3 cc/gcc/clang x flags  P1-4 Host+X-Triad gate
# NEW py lane compiles (py_compile) · boot savepoints · bundle · setup scripts ·
#     toolchain audit + PATH surface · temp-dir fallback · port cascade
# ==============================================================================

import io, json, os, re, sys, time, gzip, hashlib, shutil, socket, subprocess, threading, zipfile, py_compile, tempfile
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from multiprocessing import Pool

# ─────────────────────────── BUILD #2: C SOURCE ───────────────────────────────

C_SOURCE = r"""
/* TAU-OS v3.30-ALL — C BUILD (Fabric-8 / MPR-D / 24-Way pthread dispatch) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <pthread.h>

#define NCH 24
#define WIN 65535
#define MAXL 66
#define MINL 3
#define SRCH 512   /* BUGFIX (re-applied): cap match-search window (was WIN=65535) -- unbounded brute-force search hangs on adversarial/high-entropy input near the endpoint's own 16KB cap; confirmed live: 16KB random took 13.65s uncapped */

static const char *VFS[] = {
    "bin/tau_kernel.sys|TAU_OS_CORE_DATA_v3.27_SYNC",
    "etc/mpr_config.json|{\"mapping\":\"0xF000\",\"channels\":256}",
    "dev/fabric8_0|PHYSICAL_BUFFER_REF",
    "home/caveman/logic.rocks|STONES_HITTING_STONES"
};
#define NVFS 4

static uint8_t *payload; static size_t plen;

static void build_payload(void){
    payload = malloc(8192); plen = 0;
    for (int f = 0; f < NVFS; f++){
        const char *s = strchr(VFS[f],'|') + 1;
        size_t l = strlen(s);
        memcpy(payload + plen, s, l); plen += l;
    }
    static const char base[] = "OMNIPRESENT_FABRIC8_TAU1000_";
    size_t bl = strlen(base);
    for (size_t i = 0; i < 2400; i++)
        payload[plen++] = (uint8_t)(((uint32_t)(uint8_t)base[i % bl] * 31u + (uint32_t)i) & 0xFF);
}

static uint64_t fnv1a(const uint8_t *b, size_t n){
    uint64_t h = 0xcbf29ce484222325ULL;
    for (size_t i = 0; i < n; i++){ h ^= b[i]; h *= 0x100000001b3ULL; }
    return h;
}

static uint8_t *mpr_compress(const uint8_t *d, size_t n, size_t *olen){
    size_t cap = 2 * n + 64; uint8_t *o = malloc(cap); size_t p = 0;
    o[p++]='M'; o[p++]='P'; o[p++]='R'; o[p++]='1';
    for (int k = 0; k < 4; k++) o[p++] = (uint8_t)((n >> (8 * k)) & 0xFF);
    uint8_t lit[128]; size_t nl = 0, i = 0;
    while (i < n){
        size_t bl = 0, bd = 0;
        size_t maxd = (i < SRCH) ? i : SRCH;
        for (size_t dd = 1; dd <= maxd; dd++){
            size_t l = 0;
            while (l < MAXL && i + l < n && d[i+l] == d[i-dd+l]) l++;
            if (l > bl){ bl = l; bd = dd; if (bl == MAXL) break; }
        }
        if (bl >= MINL){
            if (nl){ o[p++] = (uint8_t)(nl-1); memcpy(o+p, lit, nl); p += nl; nl = 0; }
            if (bd <= 255){ o[p++] = (uint8_t)(0x80 | (bl-3)); o[p++] = (uint8_t)bd; }
            else { o[p++] = (uint8_t)(0xC0 | (bl-3)); o[p++] = (uint8_t)((bd>>8)&0xFF); o[p++] = (uint8_t)(bd&0xFF); }
            i += bl;
        } else {
            lit[nl++] = d[i++];
            if (nl == 128){ o[p++] = (uint8_t)(nl-1); memcpy(o+p, lit, nl); p += nl; nl = 0; }
        }
    }
    if (nl){ o[p++] = (uint8_t)(nl-1); memcpy(o+p, lit, nl); p += nl; }
    *olen = p; return o;
}

static uint8_t *mpr_decompress(const uint8_t *in, size_t ilen, size_t *olen){
    if (ilen < 8 || memcmp(in, "MPR1", 4)) return NULL;
    size_t n = 0; for (int k = 3; k >= 0; k--) n = (n << 8) | in[4+k];
    uint8_t *o = malloc(n ? n : 1); size_t p = 0, i = 8;
    while (p < n && i < ilen){
        uint8_t c = in[i++];
        if (c < 0x80){ size_t l = (size_t)c + 1; if (i + l > ilen) break; memcpy(o+p, in+i, l); p += l; i += l; }
        else {
            size_t len = (size_t)(c & 0x3F) + 3, dd;
            if (c < 0xC0){ if (i >= ilen) break; dd = in[i++]; }
            else { if (i+1 >= ilen) break; dd = ((size_t)in[i] << 8) | in[i+1]; i += 2; }
            if (dd == 0 || dd > p) break;
            for (size_t k = 0; k < len && p < n; k++){ o[p] = o[p-dd]; p++; }
        }
    }
    *olen = p; return o;
}

typedef struct { int w; size_t len; uint64_t fnv; } Slice;
static Slice slices[NCH];
static void *worker(void *arg){
    int w = (int)(intptr_t)arg;
    size_t s = plen * w / NCH, e = plen * (w+1) / NCH;
    slices[w].w = w; slices[w].len = e - s; slices[w].fnv = fnv1a(payload + s, e - s);
    return NULL;
}
static void dispatch(void){
    build_payload();
    pthread_t th[NCH];
    for (int w = 0; w < NCH; w++) pthread_create(&th[w], NULL, worker, (void*)(intptr_t)w);
    for (int w = 0; w < NCH; w++) pthread_join(th[w], NULL);
    for (int w = 0; w < NCH; w++)
        printf("W%02d slice=%d len=%zu fnv=%016llx\n", w, w, slices[w].len, (unsigned long long)slices[w].fnv);
    printf("DISPATCH_OK lanes=c workers=%d payload=%zu\n", NCH, plen);
}

static uint8_t *read_all(size_t *n){
    size_t cap = 65536, l = 0; uint8_t *b = malloc(cap); size_t r;
    while ((r = fread(b + l, 1, cap - l, stdin)) > 0){ l += r; if (l == cap){ cap *= 2; b = realloc(b, cap); } }
    *n = l; return b;
}
static int hv(int c){
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
static int selftest(void){
    build_payload();
    size_t cl; uint8_t *c = mpr_compress(payload, plen, &cl);
    size_t dl; uint8_t *d = mpr_decompress(c, cl, &dl);
    if (!d || dl != plen || memcmp(d, payload, plen)) return 1;
    size_t sn = 5000; uint8_t *s = malloc(sn); uint32_t st = 12345;
    for (size_t i = 0; i < sn; i++){
        if (i < 2500) s[i] = (uint8_t)('A' + (i % 7));
        else { st = (st * 1103515245u + 12345u) & 0x7fffffffu; s[i] = (uint8_t)(st & 0xFF); }
    }
    size_t c2l; uint8_t *c2 = mpr_compress(s, sn, &c2l);
    size_t d2l; uint8_t *d3 = mpr_decompress(c2, c2l, &d2l);
    if (!d3 || d2l != sn || memcmp(d3, s, sn)) return 1;
    printf("SELFTEST_OK c_build payload=%zu -> %zu\n", plen, cl);
    return 0;
}

int main(int argc, char **argv){
    const char *m = argc > 1 ? argv[1] : "--ping";
    if (!strcmp(m, "--ping")){ printf("PONG\n"); return 0; }
    if (!strcmp(m, "--dispatch")){ dispatch(); return 0; }
    if (!strcmp(m, "--selftest")) return selftest();
    if (!strcmp(m, "--mpr-zip")){
        size_t n; uint8_t *in = read_all(&n); size_t ol;
        uint8_t *c = mpr_compress(in, n, &ol);
        for (size_t i = 0; i < ol; i++) printf("%02x", c[i]);
        printf("\n"); return 0;
    }
    if (!strcmp(m, "--mpr-unzip")){
        size_t n; uint8_t *in = read_all(&n);
        uint8_t *hb = malloc(n/2 + 1); size_t hl = 0; int prev = -1;
        for (size_t i = 0; i < n; i++){
            int v = hv(in[i]); if (v < 0) continue;
            if (prev < 0) prev = v; else { hb[hl++] = (uint8_t)((prev << 4) | v); prev = -1; }
        }
        size_t ol; uint8_t *o = mpr_decompress(hb, hl, &ol);
        if (!o){ fprintf(stderr, "MPR_DECOMPRESS_FAIL\n"); return 1; }
        fwrite(o, 1, ol, stdout); return 0;
    }
    fprintf(stderr, "unknown mode\n"); return 2;
}
"""

# ────────────────────────── BUILD #1: RUST SOURCE ─────────────────────────────

RUST_SOURCE = r"""
use std::io::{Read, Write};

const NCH: usize = 24;
const WIN: usize = 65535;
const MAXL: usize = 66;
const MINL: usize = 3;
const SRCH: usize = 512;   // BUGFIX (re-applied): cap match-search window (was WIN) -- unbounded brute-force search hangs on adversarial/high-entropy input near the endpoint's own 16KB cap

const VFS: [&str; 4] = [
    "bin/tau_kernel.sys|TAU_OS_CORE_DATA_v3.27_SYNC",
    "etc/mpr_config.json|{\"mapping\":\"0xF000\",\"channels\":256}",
    "dev/fabric8_0|PHYSICAL_BUFFER_REF",
    "home/caveman/logic.rocks|STONES_HITTING_STONES",
];

fn build_payload() -> Vec<u8> {
    let mut p = Vec::new();
    for f in VFS.iter() {
        if let Some(pos) = f.find('|') { p.extend_from_slice(f[pos+1..].as_bytes()); }
    }
    let base = b"OMNIPRESENT_FABRIC8_TAU1000_";
    for i in 0..2400usize {
        p.push((((base[i % base.len()] as u32) * 31 + i as u32) & 0xFF) as u8);
    }
    p
}

fn fnv1a(b: &[u8]) -> u64 {
    let mut h: u64 = 0xcbf29ce484222325;
    for &x in b { h ^= x as u64; h = h.wrapping_mul(0x100000001b3); }
    h
}

fn mpr_compress(d: &[u8]) -> Vec<u8> {
    let n = d.len();
    let mut o: Vec<u8> = Vec::with_capacity(2 * n + 64);
    o.extend_from_slice(b"MPR1");
    o.extend_from_slice(&(n as u32).to_le_bytes());
    let mut lit: Vec<u8> = Vec::new();
    let mut i = 0usize;
    while i < n {
        let mut bl = 0usize; let mut bd = 0usize;
        let maxd = if i < SRCH { i } else { SRCH };
        for dd in 1..=maxd {
            let mut l = 0usize;
            while l < MAXL && i + l < n && d[i+l] == d[i-dd+l] { l += 1; }
            if l > bl { bl = l; bd = dd; if bl == MAXL { break; } }
        }
        if bl >= MINL {
            if !lit.is_empty() { o.push((lit.len()-1) as u8); o.extend_from_slice(&lit); lit.clear(); }
            if bd <= 255 { o.push(0x80 | ((bl-3) as u8)); o.push(bd as u8); }
            else { o.push(0xC0 | ((bl-3) as u8)); o.push(((bd >> 8) & 0xFF) as u8); o.push((bd & 0xFF) as u8); }
            i += bl;
        } else {
            lit.push(d[i]); i += 1;
            if lit.len() == 128 { o.push(127); o.extend_from_slice(&lit); lit.clear(); }
        }
    }
    if !lit.is_empty() { o.push((lit.len()-1) as u8); o.extend_from_slice(&lit); }
    o
}

fn mpr_decompress(input: &[u8]) -> Option<Vec<u8>> {
    if input.len() < 8 || &input[0..4] != b"MPR1" { return None; }
    let n = u32::from_le_bytes([input[4], input[5], input[6], input[7]]) as usize;
    let mut o: Vec<u8> = Vec::with_capacity(n);
    let mut i = 8usize;
    while o.len() < n && i < input.len() {
        let c = input[i]; i += 1;
        if c < 0x80 {
            let l = c as usize + 1;
            if i + l > input.len() { break; }
            o.extend_from_slice(&input[i..i+l]); i += l;
        } else {
            let len = ((c & 0x3F) as usize) + 3;
            let dd = if c < 0xC0 {
                if i >= input.len() { break; }
                let v = input[i] as usize; i += 1; v
            } else {
                if i + 1 >= input.len() { break; }
                let v = ((input[i] as usize) << 8) | input[i+1] as usize; i += 2; v
            };
            if dd == 0 || dd > o.len() { break; }
            for _ in 0..len { if o.len() >= n { break; } let b = o[o.len()-dd]; o.push(b); }
        }
    }
    Some(o)
}

fn dispatch() {
    let payload = build_payload();
    let plen = payload.len();
    let mut handles = Vec::new();
    for w in 0..NCH {
        let s = plen * w / NCH;
        let e = plen * (w + 1) / NCH;
        let slice = payload[s..e].to_vec();
        handles.push(std::thread::spawn(move || (w, e - s, fnv1a(&slice))));
    }
    for h in handles {
        let (w, len, fnv) = h.join().unwrap();
        println!("W{:02} slice={} len={} fnv={:016x}", w, w, len, fnv);
    }
    println!("DISPATCH_OK lanes=rs workers={} payload={}", NCH, plen);
}

fn read_all() -> Vec<u8> {
    let mut b = Vec::new();
    std::io::stdin().read_to_end(&mut b).ok();
    b
}
fn to_hex(b: &[u8]) -> String { b.iter().map(|x| format!("{:02x}", x)).collect() }
fn from_hex(s: &str) -> Vec<u8> {
    let ch: Vec<char> = s.chars().filter(|c| c.is_ascii_hexdigit()).collect();
    ch.chunks(2).filter_map(|p| u8::from_str_radix(&p.iter().collect::<String>(), 16).ok()).collect()
}

fn selftest() -> i32 {
    let p = build_payload();
    let c = mpr_compress(&p);
    match mpr_decompress(&c) {
        Some(d) if d == p => {},
        _ => { eprintln!("SELFTEST_FAIL roundtrip"); return 1; }
    }
    let mut s = Vec::with_capacity(5000);
    let mut st: u32 = 12345;
    for i in 0..5000usize {
        if i < 2500 { s.push(b'A' + (i % 7) as u8); }
        else {
            st = (st.wrapping_mul(1103515245).wrapping_add(12345)) & 0x7fffffff;
            s.push((st & 0xFF) as u8);
        }
    }
    let c2 = mpr_compress(&s);
    match mpr_decompress(&c2) { Some(d) if d == s => {}, _ => { eprintln!("SELFTEST_FAIL synthetic"); return 1; } }
    println!("SELFTEST_OK rs_build payload={} -> {}", p.len(), c.len());
    0
}

fn main() {
    let m = std::env::args().nth(1).unwrap_or_else(|| "--ping".into());
    match m.as_str() {
        "--ping" => println!("PONG"),
        "--dispatch" => dispatch(),
        "--selftest" => std::process::exit(selftest()),
        "--mpr-zip" => { let d = read_all(); let c = mpr_compress(&d); println!("{}", to_hex(&c)); }
        "--mpr-unzip" => {
            let mut s = String::new();
            std::io::stdin().read_to_string(&mut s).ok();
            let h = from_hex(&s);
            if let Some(o) = mpr_decompress(&h) { let _ = std::io::stdout().write_all(&o); }
            else { eprintln!("MPR_DECOMPRESS_FAIL"); std::process::exit(1); }
        }
        _ => { eprintln!("unknown mode"); std::process::exit(2); }
    }
}
"""

# ─────────────── BUILD #3: PYTHON SOURCE (single source of truth) ─────────────

PY_SOURCE = r'''
# TAU-OS v3.30-ALL — PYTHON BUILD (py_compile -> tau_os_py.pyc)
# CLI parity with C/Rust: --ping --selftest --dispatch --mpr-zip --mpr-unzip
import sys, threading

VFS = {
    "bin/tau_kernel.sys": "TAU_OS_CORE_DATA_v3.27_SYNC",
    "etc/mpr_config.json": '{"mapping":"0xF000","channels":256}',
    "dev/fabric8_0": "PHYSICAL_BUFFER_REF",
    "home/caveman/logic.rocks": "STONES_HITTING_STONES",
}
VFS_ORDER = ("bin/tau_kernel.sys", "etc/mpr_config.json", "dev/fabric8_0", "home/caveman/logic.rocks")
_BASE = b"OMNIPRESENT_FABRIC8_TAU1000_"
PAYLOAD = b"".join(VFS[k].encode() for k in VFS_ORDER) + \
          bytes(((_BASE[i % len(_BASE)] * 31 + i) & 0xFF) for i in range(2400))

def mpr_compress(d: bytes) -> bytes:
    n = len(d); out = bytearray(b"MPR1"); out += n.to_bytes(4, "little")
    lit = bytearray(); i = 0
    while i < n:
        best_len = 0; best_d = 0
        maxd = i if i < 512 else 512  # BUGFIX (re-applied): cap match-search window (was 65535/WIN) -- unbounded brute-force search hangs on adversarial/high-entropy input near the endpoint's own 16KB cap
        for dd in range(1, maxd + 1):
            l = 0
            while l < 66 and i + l < n and d[i + l] == d[i - dd + l]: l += 1
            if l > best_len:
                best_len, best_d = l, dd
                if best_len == 66: break
        if best_len >= 3:
            if lit: out.append(len(lit) - 1); out += lit; lit = bytearray()
            if best_d <= 255:
                out.append(0x80 | (best_len - 3)); out.append(best_d)
            else:
                out.append(0xC0 | (best_len - 3))
                out += bytes(((best_d >> 8) & 0xFF, best_d & 0xFF))
            i += best_len
        else:
            lit.append(d[i]); i += 1
            if len(lit) == 128: out.append(127); out += lit; lit = bytearray()
    if lit: out.append(len(lit) - 1); out += lit
    return bytes(out)

def mpr_decompress(b: bytes) -> bytes:
    if len(b) < 8 or b[:4] != b"MPR1": raise ValueError("MPR header")
    n = int.from_bytes(b[4:8], "little"); out = bytearray(); i = 8
    while len(out) < n and i < len(b):
        c = b[i]; i += 1
        if c < 0x80:
            l = c + 1
            if i + l > len(b): break
            out += b[i:i + l]; i += l
        else:
            ln = (c & 0x3F) + 3
            if c < 0xC0:
                if i >= len(b): break
                d = b[i]; i += 1
            else:
                if i + 1 >= len(b): break
                d = (b[i] << 8) | b[i + 1]; i += 2
            if d == 0 or d > len(out): break
            for _ in range(ln):
                if len(out) >= n: break
                out.append(out[-d])
    return bytes(out)

def py_selftest():
    if mpr_decompress(mpr_compress(PAYLOAD)) != PAYLOAD: return False
    s = bytearray(); st = 12345
    for i in range(5000):
        if i < 2500: s.append(ord('A') + (i % 7))
        else:
            st = (st * 1103515245 + 12345) & 0x7fffffff; s.append(st & 0xFF)
    return mpr_decompress(mpr_compress(bytes(s))) == bytes(s)

def _dispatch():
    plen = len(PAYLOAD); res = []
    def work(w):
        s = (plen * w) // 24; e = (plen * (w + 1)) // 24
        h = 0xcbf29ce484222325
        for x in PAYLOAD[s:e]:
            h = ((h ^ x) * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
        res.append((w, e - s, h))
    ths = [threading.Thread(target=work, args=(w,)) for w in range(24)]
    for t in ths: t.start()
    for t in ths: t.join()
    for (w, ln, h) in sorted(res):
        print(f"W{w:02d} slice={w} len={ln} fnv={h:016x}")
    print(f"DISPATCH_OK lanes=py workers=24 payload={plen}")

def _from_hex(s: str) -> bytes:
    it = iter(ch for ch in s if ch in "0123456789abcdefABCDEF")
    return bytes(int(a + b, 16) for a, b in zip(it, it))

if __name__ == "__main__":
    m = sys.argv[1] if len(sys.argv) > 1 else "--ping"
    if m == "--ping":
        print("PONG")
    elif m == "--selftest":
        c = mpr_compress(PAYLOAD)
        if py_selftest():
            print(f"SELFTEST_OK py_build payload={len(PAYLOAD)} -> {len(c)}"); sys.exit(0)
        print("SELFTEST_FAIL", file=sys.stderr); sys.exit(1)
    elif m == "--dispatch":
        _dispatch()
    elif m == "--mpr-zip":
        print(mpr_compress(sys.stdin.buffer.read()).hex())
    elif m == "--mpr-unzip":
        try:
            o = mpr_decompress(_from_hex(sys.stdin.read()))
        except Exception:
            print("MPR_DECOMPRESS_FAIL", file=sys.stderr); sys.exit(1)
        sys.stdout.buffer.write(o)
    else:
        print("unknown mode", file=sys.stderr); sys.exit(2)
'''

# ─────────────── BUNDLED SETUP SCRIPTS (extracted at boot) ────────────────────

SETUP_WIN = r"""@echo off
rem OMNIPRESENT OS v3.30-ALL — toolchain setup (WINDOWS). Idempotent.
echo === OMNIPRESENT OS WINDOWS SETUP ===
where winget >nul 2>nul
if %errorlevel%==0 (
    echo [1/3] Installing Rustup via winget...
    winget install --id Rustlang.Rustup -e --accept-source-agreements --accept-package-agreements
    echo [2/3] Installing MSYS2 via winget...
    winget install --id MSYS2.MSYS2 -e --accept-source-agreements --accept-package-agreements
    echo [3/3] NOW OPEN THE "MSYS2 UCRT64" SHELL AND RUN:
    echo     pacman -S mingw-w64-ucrt-x86_64-gcc
) else (
    echo winget not found. Manual steps:
    echo   1. Rust:      https://rust-lang.org  (default install)
    echo   2. MSYS2:     https://msys2.org  then in the UCRT64 shell:
    echo      pacman -S mingw-w64-ucrt-x86_64-gcc
    echo   3. Add  C:\msys64\ucrt64\bin  to your PATH
    echo   4. Python:    https://python.org  - CHECK "Add python.exe to PATH"
)
echo Setup finished. Restart the supervisor or type 'health' in CAVE-AI.
"""

SETUP_LINUX = r"""#!/bin/sh
# OMNIPRESENT OS v3.30-ALL — toolchain setup (LINUX). Idempotent.
echo "=== OMNIPRESENT OS LINUX SETUP ==="
if command -v apt-get >/dev/null 2>&1; then
    echo "[1/2] apt: build-essential rustc python3 (will ask for your sudo password)"
    sudo apt update
    sudo apt install -y build-essential rustc python3
elif command -v dnf >/dev/null 2>&1; then
    echo "[1/2] dnf: gcc gcc-c++ make rust python3"
    sudo dnf install -y gcc gcc-c++ make rust python3
elif command -v pacman >/dev/null 2>&1; then
    echo "[1/2] pacman: base-devel rust python"
    sudo pacman -S --needed base-devel rust python
else
    echo "No apt/dnf/pacman found. Install cc/gcc/clang + rustc + python3 manually."
fi
echo "[2/2] Verifying..."
command -v cc || true; command -v gcc || true; command -v rustc || true; command -v python3 || true
echo "Done. If sudo failed, run this script yourself in a terminal."
"""

SETUP_MAC = r"""#!/bin/sh
# OMNIPRESENT OS v3.30-ALL — toolchain setup (MACOS). Idempotent.
echo "=== OMNIPRESENT OS MACOS SETUP ==="
echo "[1/3] Xcode Command Line Tools (GUI dialog may appear)"
xcode-select --install 2>/dev/null || echo "  already installed"
echo "[2/3] Homebrew"
command -v brew >/dev/null 2>&1 || /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
echo "[3/3] rustc"
brew install rustc 2>/dev/null || echo "  brew failed - try: curl https://sh.rustup.rs -sSf | sh"
echo "Done."
"""

RUN_TXT = """OMNIPRESENT OS v3.30-ALL — PORTABLE BUNDLE
================================================
1. Unzip anywhere.
2. Missing compilers? run setup/setup_windows.bat (Windows)
   or: sh setup/setup_linux.sh | sh setup/setup_macos.sh
3. python omnipresent_os.py
4. Open the port printed in the log (cascade starts at 9000).

src/    = the three lane sources (embedded in the supervisor)
bin/    = prebuilt artifacts, host-matching only (sources rebuild automatically)
savepoints/ = latest known-good snapshots
The supervisor re-extracts and recompiles anything missing on boot.
"""

_PYNS = {"__name__": "tau_os_py", "__file__": "tau_os.py"}
exec(compile(PY_SOURCE, "tau_os.py", "exec"), _PYNS)   # codec lives ONCE
PAYLOAD = _PYNS["PAYLOAD"]
mpr_compress, mpr_decompress = _PYNS["mpr_compress"], _PYNS["mpr_decompress"]
py_selftest = _PYNS["py_selftest"]

def _worker(w):  # module-level so multiprocessing spawn can pickle it (P0-3)
    L = len(PAYLOAD); s = (L * w) // 24; e = (L * (w + 1)) // 24
    h = 0xcbf29ce484222325
    for x in PAYLOAD[s:e]:
        h = ((h ^ x) * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
    return (w, e - s, h)

# ───────────────────────────── TRIAD SUPERVISOR ───────────────────────────────

BASE_DIR = Path(__file__).resolve().parent
BUILD = BASE_DIR / "build"
SAVEPOINTS = BUILD / "savepoints"
SETUP_DIR = BUILD / "setup"
MPRDIR = BUILD / "mpr"
EXT = ".exe" if os.name == "nt" else ""
CANON = {"c": C_SOURCE, "rs": RUST_SOURCE, "py": PY_SOURCE}
SRCP = {"c": BUILD / "tau_os.c", "rs": BUILD / "tau_os.rs", "py": BUILD / "tau_os.py"}
BINP = {"c": BUILD / ("tau_os_c" + EXT), "rs": BUILD / ("tau_os_rs" + EXT), "py": BUILD / "tau_os_py.pyc"}
SHA = {l: hashlib.sha256(CANON[l].encode()).hexdigest() for l in CANON}

ST = {l: {"up": False, "detail": "", "last_err": "", "repairs": 0, "workers": 0}
      for l in ("rs", "c", "py")}
LOG = []
RAM = bytearray(65536)
SCRUB = re.compile(r"click here|subscribe now|buy now|limited offer|sponsored", re.I)
LANEM = {"rs": "RUST", "c": "C", "py": "PYTHON"}
_POOL = None
T0 = time.time()
LASTRATIO = 0.0

UI_PORT = 0
PORTS = (9000, 8327, 8080, 8000, 5000, 8888, 7777, 9090, 3000, 7000)

# ───────────── DYNAMIC OMNIPRESENT COMPRESSION (MPR at rest) ──────────────────
# Adaptive container: OMPR + u16 nchunks + per chunk (u16 clen + MPR1 stream).
# "Unless needed" rule: entropy data and poor ratios stay RAW automatically.

MEM = {"pack_ops": 0, "bytes_in": 0, "bytes_out": 0, "log_segments": 0, "log_saved": 0,
       "ram_pages_cold": 0, "ram_saved": 0, "gz_hits": 0}
HOT_N = 80      # hot log window (plain)
SPILL_N = 160   # lines per archived segment
LOGARCH = []    # cold history: list of (mode, data)
TASKS = []      # durable-task ledger (Temporal-style shim)
RAMCOLD = {}    # page -> (mode, blob); page stays zeroed in hot RAM while cold
RAM_PAGE = 1024
RAM_HOT_PAGE = 0xF000 // RAM_PAGE   # pages 60..63 (pulse region) stay hot

def _mpr_worth(b: bytes) -> bool:
    """Fast adaptive pre-check: repetitive data packs, entropy stays raw."""
    if len(b) < 64: return False
    return len(set(b[:256])) <= 96

def mpr_pack(b: bytes, threshold: float = 0.92):
    if not _mpr_worth(b): return ("raw", b)
    chunks = [b[i:i + RAM_PAGE] for i in range(0, len(b), RAM_PAGE)]
    out = bytearray(b"OMPR"); out += len(chunks).to_bytes(2, "little")
    for c in chunks:
        m = mpr_compress(c)
        out += len(m).to_bytes(2, "little"); out += m
    if len(out) >= len(b) * threshold: return ("raw", b)   # dynamic: must pay
    return ("mpr", bytes(out))

def mpr_unpack(mode: str, data: bytes) -> bytes:
    if mode == "raw": return data
    if data[:4] != b"OMPR": raise ValueError("OMPR header")
    nch = int.from_bytes(data[4:6], "little"); i = 6; out = bytearray()
    for _ in range(nch):
        cl = int.from_bytes(data[i:i + 2], "little"); i += 2
        out += mpr_decompress(data[i:i + cl]); i += cl
    return bytes(out)

def _mem_note(bi, bo, mode):
    MEM["pack_ops"] += 1; MEM["bytes_in"] += bi
    if mode == "mpr": MEM["bytes_out"] += bo

def log_spill():
    """Move old lines from the hot window into the cold archive (MPR unless needed)."""
    if len(LOG) <= HOT_N + SPILL_N: return
    cold = LOG[:len(LOG) - HOT_N]
    del LOG[:len(LOG) - HOT_N]
    blob = "\n".join(cold).encode("utf-8")
    mode, data = mpr_pack(blob)
    LOGARCH.append((mode, data)); MEM["log_segments"] += 1
    if mode == "mpr": MEM["log_saved"] += len(blob) - len(data)
    _mem_note(len(blob), len(data), mode)
    klog(f"[MEM] log segment archived: {mode} {len(blob)} -> {len(data)} bytes")

def log_full():
    out = []
    for mode, data in LOGARCH:
        try: out += mpr_unpack(mode, data).decode("utf-8", "replace").splitlines()
        except Exception: out.append("[MEM] segment unreadable")
    out += LOG
    return out

def ram_sweep():
    """TAU-RAM shadow: MPR-pack quiet (all-zero) 1KB pages outside the pulse
    region. Transparent: a cold page reads back exactly as it was; any write
    restores it (ram_write). Purely additive — pulse/RAM behavior unchanged."""
    zeros = bytes(RAM_PAGE)
    for page in range(RAM_HOT_PAGE):
        if page in RAMCOLD: continue
        if RAM[page * RAM_PAGE:(page + 1) * RAM_PAGE] == zeros:
            mode, blob = mpr_pack(zeros)
            if mode == "mpr":
                RAMCOLD[page] = (mode, blob)
                MEM["ram_pages_cold"] = len(RAMCOLD)
                MEM["ram_saved"] += RAM_PAGE - len(blob)
                _mem_note(RAM_PAGE, len(blob), mode)

def ram_write(addr: int, val: int):
    """Transparent write: restores a cold page to hot RAM first."""
    page = addr // RAM_PAGE
    if page in RAMCOLD:
        mode, blob = RAMCOLD.pop(page)
        MEM["ram_saved"] -= (RAM_PAGE - len(blob))
        MEM["ram_pages_cold"] = len(RAMCOLD)
        klog(f"[MEM] TAU-RAM page {page} restored to hot RAM on write")
    RAM[addr] = val & 0xFF

def pack_artifacts():
    """On-demand artifact pack: MPR the canonical lane sources to build/mpr/."""
    MPRDIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for lane, src in CANON.items():
        b = src.encode("utf-8")
        mode, data = mpr_pack(b)
        p = MPRDIR / f"tau_os.{lane}.mpr"
        if mode == "mpr": p.write_bytes(data)
        _mem_note(len(b), len(data), mode)
        rows.append(f"{lane}: {len(b)} -> {len(data)} ({mode})")
    return rows

def memthread():
    """Background compressor: dynamic, non-blocking, 'unless needed' aware."""
    while True:
        try:
            log_spill(); ram_sweep()
        except Exception as e:
            klog(f"[MEM] sweep error: {repr(e)[:100]}")
        time.sleep(5.0)

def _task(kind, state="OK", retries=0):
    TASKS.append({"id": f"t{len(TASKS)+1:04d}", "kind": kind, "state": state,
                  "retries": retries, "ts": time.strftime('%H:%M:%S')})
    if len(TASKS) > 200: del TASKS[:50]

# ─────────────────────────── SUPERVISOR CORE ───────────────────────────────

def klog(msg):
    LOG.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
    if len(LOG) > 400: del LOG[:100]
    print(msg)

def make_savepoint(label="manual"):
    try:
        SAVEPOINTS.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y%m%d-%H%M%S")
        for lane in CANON:
            (SAVEPOINTS / f"{ts}.{lane}.bak").write_bytes(CANON[lane].encode("utf-8"))
        try:
            (SAVEPOINTS / f"{ts}.supervisor.bak").write_bytes(Path(__file__).read_bytes())
        except Exception:
            pass
        olds = sorted(SAVEPOINTS.glob("*.bak"))
        for p in olds[:-20]:
            p.unlink(missing_ok=True)
        klog(f"[SAVEPOINT] {ts} ({label}) — {len(CANON)} lane sources + supervisor snapshot")
        _task("savepoint")
        return ts
    except Exception as e:
        klog(f"[SAVEPOINT] FAILED: {repr(e)[:120]}")
        return None

def extract(lane):
    tmp = SRCP[lane].parent / (SRCP[lane].name + ".tmp")
    tmp.write_bytes(CANON[lane].encode("utf-8"))          # P0-A: bytes, not text-mode
    os.replace(tmp, SRCP[lane])

def intact(lane):
    return SRCP[lane].exists() and \
           hashlib.sha256(SRCP[lane].read_bytes()).hexdigest() == SHA[lane]

def compile_build(lane):
    tmp = str(BINP[lane]) + ".new"                        # P1-2: atomic binary swap
    if lane == "py":
        try:
            py_compile.compile(str(SRCP[lane]), cfile=tmp, doraise=True)
            os.replace(tmp, BINP[lane])
            return True, ""
        except Exception as e:
            return False, repr(e).strip()[-300:]
    if lane == "c":
        last = "no compiler found (need cc/gcc/clang)"
        for cc in ("cc", "gcc", "clang"):
            for extra in (["-pthread"], ["-lpthread"], []):   # P1-3: flag cascade
                try:
                    r = subprocess.run([cc, "-O2", *extra, "-o", tmp, str(SRCP[lane])],
                                       capture_output=True, text=True, timeout=180)
                except FileNotFoundError:
                    break
                if r.returncode == 0 and Path(tmp).exists():
                    try:
                        os.replace(tmp, BINP[lane]); return True, ""
                    except OSError as e:
                        return False, f"binary swap blocked (in use?): {repr(e)[-140:]}"
                last = r.stderr.strip()[-300:]
        return False, last
    try:
        r = subprocess.run(["rustc", "-O", "-o", tmp, str(SRCP[lane])],
                           capture_output=True, text=True, timeout=300)
    except FileNotFoundError:
        return False, "toolchain 'rustc' not installed"
    if r.returncode == 0 and Path(tmp).exists():
        try:
            os.replace(tmp, BINP[lane]); return True, ""
        except OSError as e:
            return False, f"binary swap blocked (in use?): {repr(e)[-140:]}"
    return False, r.stderr.strip()[-300:]

def ping(lane):
    try:
        cmd = [sys.executable, str(BINP[lane])] if lane == "py" else [str(BINP[lane])]
        r = subprocess.run(cmd + ["--ping"], capture_output=True, timeout=5)
        return r.stdout.startswith(b"PONG")
    except Exception:
        return False

def run_selftest(lane):
    try:
        cmd = [sys.executable, str(BINP[lane])] if lane == "py" else [str(BINP[lane])]
        r = subprocess.run(cmd + ["--selftest"], capture_output=True, timeout=60)
        return r.returncode == 0
    except Exception:
        return False

def boot_lane(lane):
    if not intact(lane): extract(lane)
    ok, err = compile_build(lane)
    if not ok:
        ST[lane].update(up=False, detail=err[-160:], last_err=err[-160:])
        _task(f"boot:{lane}", state="FAIL", retries=0)
        klog(f"[TRIAD] {LANEM[lane]} lane COMPILE FAIL — DOWN")
        return
    if run_selftest(lane):
        ST[lane].update(up=True, detail="", last_err="")
        klog(f"[TRIAD] {LANEM[lane]} lane compiled — ONLINE")
    else:
        ST[lane].update(up=False, detail="selftest fail", last_err="selftest fail")

def watchdog():
    while True:
        pymark = BUILD / "py.down"
        for lane in ("c", "rs", "py"):
            if lane == "py" and pymark.exists():          # P1-1: fault toggle honored
                if ST[lane]["up"]:
                    ST[lane].update(up=False, detail="fault injected (py.down)")
                    klog(f"[TRIAD] {LANEM[lane]} lane FAILURE — fault injected")
                continue
            src_ok, bin_ok = intact(lane), ping(lane)
            if src_ok and bin_ok:
                if not ST[lane]["up"]:
                    if lane == "py" and not py_selftest():
                        pass
                    else:
                        ST[lane].update(up=True, detail="", last_err="")
                        klog(f"[TRIAD] {LANEM[lane]} lane restored")
                continue
            was_up = ST[lane]["up"]
            ST[lane]["up"] = False
            if was_up: klog(f"[TRIAD] {LANEM[lane]} lane FAILURE — repairing")
            if not src_ok: extract(lane)
            ok, err = compile_build(lane)
            if ok and run_selftest(lane):
                ST[lane].update(up=True, detail="", last_err=""); ST[lane]["repairs"] += 1
                _task(f"repair:{lane}", state="REBUILT", retries=ST[lane]["repairs"])
                klog(f"[TRIAD] {LANEM[lane]} lane REBUILT — ONLINE")
            else:
                detail = (err or "selftest fail").strip()[-160:]
                if detail != ST[lane]["last_err"]:
                    ST[lane]["last_err"] = detail
                    _task(f"repair:{lane}", state="RETRY", retries=ST[lane]["repairs"])
                    klog(f"[TRIAD] {LANEM[lane]} repair retry: {detail[:120]}")
        time.sleep(2.0)

def triad_dispatch():
    global _POOL
    lanes = {}
    for lane in ("rs", "c", "py"):
        if not ST[lane]["up"]: continue
        try:
            if lane == "py":
                try: res = _POOL.map(_worker, range(24)) if _POOL else [_worker(w) for w in range(24)]
                except Exception:
                    _POOL = None; res = [_worker(w) for w in range(24)]
                rows = [(f"W{w:02d}", ln, f"{h:016x}") for (w, ln, h) in res]
            else:
                r = subprocess.run([str(BINP[lane]), "--dispatch"], capture_output=True, text=True, timeout=60)
                rows = [(f"W{int(w):02d}", int(l), h) for w, l, h in
                        re.findall(r"W(\d+)\s+slice=\d+\s+len=(\d+)\s+fnv=([0-9a-f]+)", r.stdout)]
            lanes[lane] = rows; ST[lane]["workers"] = len(rows)
        except Exception as e:
            ST[lane].update(up=False, detail=repr(e)[:160])
    maps = {l: {w: (ln, f) for w, ln, f in rows} for l, rows in lanes.items()}
    ref = next(iter(maps.values())) if maps else None
    verified = len(maps) >= 2 and all(m == ref for m in maps.values())
    out = {l: [{"w": w, "len": ln, "fnv": f, "ok": (ref.get(w) == (ln, f)) if ref else False}
               for w, ln, f in rows] for l, rows in lanes.items()}
    return {"lanes": out, "workers_total": sum(len(r) for r in lanes.values()), "verified": verified}

def triad_mpr(sample: bytes):
    global LASTRATIO
    mine = mpr_compress(sample)
    lanes = {"py": {"orig": len(sample), "comp": len(mine), "hex": mine.hex()}}
    for lane in ("c", "rs"):
        if ST[lane]["up"]:
            try:
                r = subprocess.run([str(BINP[lane]), "--mpr-zip"], input=sample, capture_output=True, timeout=60)
                lanes[lane] = {"orig": len(sample), "comp": len(r.stdout.strip()) // 2, "hex": r.stdout.decode().strip()}
            except Exception: pass
    identical = len({v["hex"] for v in lanes.values()}) == 1
    roundtrip_ok = (mpr_decompress(mine) == sample)          # verify against the ORIGINAL bytes, not just cross-lane agreement
    LASTRATIO = round(len(mine) / len(sample), 3) if sample else 0.0
    return {"lanes": lanes, "identical": identical, "roundtrip_ok": roundtrip_ok, "ratio": LASTRATIO}

def pulse():
    ent = os.urandom(256)
    seed = hashlib.sha256(ent + bytes(RAM[0xF000:0xF100])).digest()
    for i in range(256): RAM[0xF000 + i] = seed[i % 32] ^ ent[i]
    return list(RAM[0xF000:0xF100])

def kill_lane(lane):
    if lane == "py":                                      # P1-1: toggle, not dead file
        m = BUILD / "py.down"
        if m.exists(): m.unlink()
        else: m.write_bytes(b"fault")
    elif lane in ("c", "rs"):
        tmp = SRCP[lane].parent / (SRCP[lane].name + ".tmp")
        tmp.write_bytes(b"// CORRUPTED\n")
        os.replace(tmp, SRCP[lane])
        try: BINP[lane].unlink(missing_ok=True)
        except OSError: pass

# ─────────────── BUNDLE: self-provisioning & portable export ──────────────────

def emit_setup_scripts():
    SETUP_DIR.mkdir(parents=True, exist_ok=True)
    (SETUP_DIR / "setup_windows.bat").write_bytes(SETUP_WIN.encode("utf-8"))
    (SETUP_DIR / "setup_linux.sh").write_bytes(SETUP_LINUX.encode("utf-8"))
    (SETUP_DIR / "setup_macos.sh").write_bytes(SETUP_MAC.encode("utf-8"))

def toolchain_audit():
    cc = next((c for c in ("cc", "gcc", "clang") if shutil.which(c)), None)
    rs = shutil.which("rustc")
    klog(f"[TOOLCHAIN] python : {sys.executable}")
    klog("[TOOLCHAIN] C      : " + (cc if cc else "MISSING -> type 'setup' in CAVE-AI, or run build/setup script"))
    klog("[TOOLCHAIN] rustc  : " + (rs if rs else "MISSING -> type 'setup' in CAVE-AI, or run build/setup script"))
    if os.name == "nt":  # surface freshly-installed toolchains without a restart
        for extra in (r"C:\msys64\ucrt64\bin", str(Path.home() / ".cargo" / "bin")):
            if Path(extra).exists() and extra not in os.environ.get("PATH", ""):
                os.environ["PATH"] += os.pathsep + extra
                klog(f"[TOOLCHAIN] PATH += {extra}")
    return {"c": cc, "rs": rs}

def run_setup():
    emit_setup_scripts()
    if os.name == "nt":
        script, cmd = "setup_windows.bat", ["cmd", "/c", str(SETUP_DIR / "setup_windows.bat")]
    elif sys.platform == "darwin":
        script, cmd = "setup_macos.sh", ["sh", str(SETUP_DIR / "setup_macos.sh")]
    else:
        script, cmd = "setup_linux.sh", ["sh", str(SETUP_DIR / "setup_linux.sh")]
    klog(f"[SETUP] running {script} ...")
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        out = (r.stdout + "\n" + r.stderr).strip()
    except subprocess.TimeoutExpired:
        out = "timed out after 900s (a GUI installer may still be open — finish it, then type 'health')"
    except FileNotFoundError as e:
        out = f"cannot launch installer: {repr(e)} — run build/setup/{script} manually in a terminal"
    if os.name == "nt":
        for extra in (r"C:\msys64\ucrt64\bin", str(Path.home() / ".cargo" / "bin")):
            if Path(extra).exists() and extra not in os.environ.get("PATH", ""):
                os.environ["PATH"] += os.pathsep + extra
    klog("[SETUP] finished — watchdog retries lanes every 2s")
    return out

def make_bundle(label="boot"):
    try:
        zp = BUILD / "omnipresent_bundle.zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("RUN.txt", RUN_TXT)
            try: z.write(Path(__file__), "omnipresent_os.py")
            except Exception: pass
            for lane in CANON:
                z.writestr(f"src/tau_os.{lane}", CANON[lane])
            z.writestr("setup/setup_windows.bat", SETUP_WIN)
            z.writestr("setup/setup_linux.sh", SETUP_LINUX)
            z.writestr("setup/setup_macos.sh", SETUP_MAC)
            for p in BINP.values():
                if p.exists(): z.write(p, f"bin/{p.name}")
            try:
                for p in sorted(SAVEPOINTS.glob("*.bak"))[-4:]:
                    z.write(p, f"savepoints/{p.name}")
            except Exception: pass
        klog(f"[BUNDLE] {zp.name} ({zp.stat().st_size} bytes) written ({label}) — portable copy of the OS")
        _task("bundle", label)
        return zp
    except Exception as e:
        klog(f"[BUNDLE] FAILED: {repr(e)[:120]}")
        return None

# ───────────────────── SYSTEMS MANAGER (external frameworks) ─────────────────

def systems_scan():
    e = os.environ
    return {
        "kubernetes": {"detected": bool(e.get("KUBERNETES_SERVICE_HOST")),
                       "probes": {"liveness": "/healthz", "readiness": "/readyz", "metrics": "/metrics"},
                       "note": "bind is 127.0.0.1 — in-cluster probes need hostNetwork or port-forward"},
        "dapr":       {"detected": bool(e.get("DAPR_HTTP_PORT")),
                       "sidecar_http": e.get("DAPR_HTTP_PORT", ""), "probe": "/v1.0/healthz",
                       "note": "sidecar detection + health probe; lanes stay subprocesses"},
        "nomad":      {"detected": bool(e.get("NOMAD_JOB_NAME")),
                       "note": "NOMAD_PORT_ui honored before port cascade; /metrics shared"},
        "temporal":   {"detected": bool(e.get("TEMPORAL_ADDRESS")),
                       "note": "durable-task ledger at /tasks — repairs/savepoints are retried tasks"},
        "ray":        {"detected": bool(e.get("RAY_ADDRESS")),
                       "note": "ST doubles as actor table; /systems is the GCS-style view"},
        "vertx":      {"detected": True,
                       "note": "event-bus shim: POST/GET /eb/<topic>"},
        "otp":        {"detected": True,
                       "note": "Erlang/OTP let-it-crash: /kill + watchdog = one_for_one restarts"},
    }

EB = {}  # topic -> [events]

def eb_publish(topic: str, msg: str):
    EB.setdefault(topic, []).append(f"[{time.strftime('%H:%M:%S')}] {msg[:400]}")
    if len(EB[topic]) > 50: del EB[topic][:-50]
    klog(f"[EB] {topic}: {msg[:80]}")

def metrics_text():
    L = []
    for lane in ("rs", "c", "py"):
        L.append(f'omnipresent_lane_up{{lane="{lane}"}} {1 if ST[lane]["up"] else 0}')
        L.append(f'omnipresent_repairs_total{{lane="{lane}"}} {ST[lane]["repairs"]}')
        L.append(f'omnipresent_workers{{lane="{lane}"}} {ST[lane]["workers"]}')
    ratio = (MEM["bytes_out"] / MEM["bytes_in"]) if MEM["bytes_in"] else 1.0
    L += [f"omnipresent_dispatch_verified {1 if MEM['pack_ops'] >= 0 and ST['c']['up'] and ST['rs']['up'] else 0}",
          f"omnipresent_mpr_last_ratio {LASTRATIO}",
          f"omnipresent_mem_ratio {round(ratio, 3)}",
          f"omnipresent_log_archived_segments {MEM['log_segments']}",
          f"omnipresent_log_saved_bytes {MEM['log_saved']}",
          f"omnipresent_ram_pages_cold {MEM['ram_pages_cold']}",
          f"omnipresent_ram_shadow_saved_bytes {MEM['ram_saved']}",
          f"omnipresent_gzip_responses {MEM['gz_hits']}",
          f"omnipresent_tasks_total {len(TASKS)}",
          f"omnipresent_uptime_seconds {int(time.time() - T0)}",
          f"omnipresent_ui_port {UI_PORT}"]
    return "\n".join(L) + "\n"

# ─────────────────────────── CAVE-AI BRAIN ───────────────────────────────

def cave_chat(text: str) -> str:
    raw = (text or "").strip().lower()
    def w(ks): return any(re.search(r"(?<![a-z0-9])" + re.escape(k) + r"(?![a-z0-9])", raw) for k in ks)
    if w(["dispatch"]):
        d = triad_dispatch()
        return f"DISPATCH: workers={d['workers_total']} verified={d['verified']}"
    if raw.startswith("mpr"):
        sample = text.strip()[3:].strip().encode()[:4096] or b"caveman"
        r = triad_mpr(sample)
        return f"MPR: identical={r['identical']} ratio={r['ratio']} lanes={sorted(r['lanes'])}"
    if w(["health", "status"]): return f"TRIAD: {[LANEM[l] for l in ST if ST[l]['up']]} ONLINE."
    if w(["pulse"]):
        ch = pulse()
        return f"PULSE: 256 CHANNELS REFRESHED. head={bytes(ch[:8]).hex()}"
    if w(["savepoint", "backup"]):
        ts = make_savepoint("chat")
        return f"SAVEPOINT {ts} WRITTEN TO build/savepoints" if ts else "SAVEPOINT FAILED"
    if w(["setup"]):
        return ("SETUP RUN (blocks until installers finish). Watchdog retries lanes every 2s — "
                "type 'health'. Output tail:\n" + run_setup()[-600:])
    if w(["bundle"]):
        zp = make_bundle("chat")
        return f"BUNDLE: {zp}" if zp else "BUNDLE FAILED"
    if w(["systems", "integrations"]):
        s = systems_scan()
        det = [k.upper() for k, v in s.items() if v["detected"]]
        return f"SYSTEMS DETECTED: {det or ['(none external)']} | endpoints: /healthz /readyz /v1.0/healthz /metrics /tasks /eb/<topic> /systems"
    if w(["compress"]):
        log_spill(); ram_sweep()
        rows = pack_artifacts()
        return ("MEM SWEEP DONE. " + "; ".join(rows) +
                f" | log_saved={MEM['log_saved']}B ram_shadow={MEM['ram_saved']}B gz={MEM['gz_hits']}")
    if w(["logfull"]):
        return f"LOG ARCHIVE DECOMPRESSED: {len(log_full())} lines total ({MEM['log_segments']} segments)"
    if w(["eb"]):
        return f"EB TOPICS: {sorted(EB) or ['(empty — POST /eb/<topic>)']}"
    m = re.match(r"poke (\d+)(?: (\d+))?$", raw)
    if m:
        addr = int(m.group(1)) % 65536; val = int(m.group(2) or 1)
        ram_write(addr, val)
        return f"POKED RAM[{addr}]={val & 0xFF} (cold page restored if it was packed)"
    if w(["whoami", "name"]): return "ME CAVE-AI. ME LIVE IN YOUR RAM. TRIAD IS MY BODY."
    if w(["kill"]): return "UGH. USE 'kill <rs/c/py>' TO SABOTAGE A LANE. WATCH ME REBUILD."
    if w(["help"]): return ("COMMANDS: health | dispatch | mpr <text> | kill | pulse | whoami | savepoint | "
                            "setup | bundle | systems | compress | logfull | eb | poke <addr> [val]")
    return "ME NO UNDERSTAND. TRY 'health' OR 'systems'."

# ─────────────────────────────── HTTP LAYER ───────────────────────────────────

HTML_SOURCE = r"""
<!DOCTYPE html><html><head><title>Omnipresent OS v3.30-ALL</title>
<style>body{background:#000;color:#0f0;font-family:monospace;padding:20px;}
.lane{border:1px solid #0f0;padding:10px;margin:10px 0;}
.up{color:#0f0;} .down{color:#f00;}
pre{background:#111;padding:10px;overflow-x:auto;white-space:pre-wrap;}
button,input{background:#000;color:#0f0;border:1px solid #0f0;font-family:monospace;padding:4px 8px;margin:4px 4px 4px 0;}
</style></head><body>
<h1>OMNIPRESENT OS v3.30-ALL :__PORT__</h1>
<div style="margin:6px 0 12px;"><a href="/modern" style="color:#0f0;">[ Modern UI tab ]</a></div>
<div id="status">BOOTING TRIAD...</div>
<div id="lanes"></div>
<div id="sysmem" class="lane">SYSTEMS: scanning...</div>
<button onclick="doDispatch()">DISPATCH</button>
<input id="mprtext" size="40" placeholder="MPR sample text">
<button onclick="doMpr()">MPR</button>
<button onclick="doSys()">SYS</button>
<input id="chatin" size="40" placeholder="CAVE-AI: health | systems | compress | dispatch | mpr x | pulse | savepoint">
<button onclick="doChat()">SAY</button>
<pre id="out"></pre>
<pre id="log"></pre>
<script>
const H = {'Content-Type':'text/plain','X-Triad':'1'};
async function tick(){
    const r = await fetch('/tick'); const d = await r.json();
    let h = ''; for(let l in d.lanes){
        let s = d.lanes[l];
        h += `<div class="lane">${l.toUpperCase()}: <span class="${s.up?'up':'down'}">${s.up?'ONLINE':'DOWN'}</span> (${s.repairs} repairs)${s.detail?' &middot; '+s.detail:''}</div>`;
    }
    document.getElementById('lanes').innerHTML = h;
    const det = Object.entries(d.sys||{}).filter(([k,v])=>v.detected).map(([k])=>k.toUpperCase()).join(' · ') || 'none external';
    const m = d.mem||{};
    document.getElementById('sysmem').textContent =
        'SYSTEMS: ' + det +
        ' | MEM: log segs ' + (m.log_segments||0) + ' (saved ' + (m.log_saved||0) + 'B)' +
        ', ram cold ' + (m.ram_pages_cold||0) + ' pages (shadow ' + (m.ram_saved||0) + 'B)' +
        ', gzip ' + (m.gz_hits||0) + ', tasks ' + (d.tasks||0);
    document.getElementById('log').textContent = (d.log||[]).join('\n');
}
async function doDispatch(){
    const d = await (await fetch('/dispatch')).json();
    document.getElementById('out').textContent = 'DISPATCH verified=' + d.verified + ' workers_total=' + d.workers_total;
}
async function doMpr(){
    const t = document.getElementById('mprtext').value || 'caveman';
    const d = await (await fetch('/mpr', {method:'POST', headers:H, body:t})).json();
    document.getElementById('out').textContent = 'MPR identical=' + d.identical + ' ratio=' + d.ratio +
        '\n' + Object.entries(d.lanes).map(([k,v]) => k + ': ' + v.orig + ' -> ' + v.comp).join('\n');
}
async function doSys(){
    const d = await (await fetch('/systems')).json();
    document.getElementById('out').textContent = JSON.stringify(d, null, 1);
}
async function doChat(){
    const t = document.getElementById('chatin').value;
    if(!t) return;
    document.getElementById('out').textContent = 'CAVE-AI thinking... (setup/compress can take a while)';
    const d = await (await fetch('/chat', {method:'POST', headers:H, body:t})).json();
    document.getElementById('out').textContent = 'CAVE-AI: ' + d.reply;
}
setInterval(tick, 2000); tick();
</script></body></html>
"""

MODERN_HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Omnipresent OS v3.30-ALL — Modern</title>
<style>
  :root {
    --bg: #0b0f14;
    --panel: #12181f;
    --border: #1e2a36;
    --text: #e6edf3;
    --muted: #8b9bb4;
    --green: #3dd68c;
    --red: #ff6b6b;
    --amber: #f0b429;
    --blue: #5b9fd4;
    --accent: #7c5cff;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; padding: 0;
    font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
    background: var(--bg); color: var(--text);
    line-height: 1.45;
  }
  header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 20px; border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, #141b24, var(--bg));
  }
  header h1 {
    margin: 0; font-size: 1.15rem; font-weight: 600; letter-spacing: 0.02em;
  }
  header h1 span { color: var(--green); }
  .badge {
    font-size: 0.75rem; padding: 3px 8px; border-radius: 999px;
    background: #1a2330; color: var(--muted); border: 1px solid var(--border);
  }
  .tabs {
    display: flex; gap: 0; border-bottom: 1px solid var(--border);
    background: #0e141b; padding: 0 16px;
  }
  .tabs a {
    color: var(--muted); text-decoration: none; padding: 10px 16px;
    font-size: 0.85rem; border-bottom: 2px solid transparent;
  }
  .tabs a:hover { color: var(--text); }
  .tabs a.active { color: var(--green); border-bottom-color: var(--green); }
  .wrap { max-width: 1100px; margin: 0 auto; padding: 18px 16px 40px; }
  .grid {
    display: grid; gap: 14px;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  }
  .card {
    background: var(--panel); border: 1px solid var(--border);
    border-radius: 10px; padding: 14px 16px;
  }
  .card h2 {
    margin: 0 0 10px; font-size: 0.8rem; text-transform: uppercase;
    letter-spacing: 0.06em; color: var(--muted); font-weight: 600;
  }
  .lane {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 12px; margin: 6px 0; border-radius: 8px;
    background: #0e141b; border: 1px solid var(--border);
  }
  .lane .name { font-weight: 600; font-size: 0.95rem; }
  .status { font-size: 0.8rem; font-weight: 600; }
  .up { color: var(--green); }
  .down { color: var(--red); }
  .meta { font-size: 0.78rem; color: var(--muted); margin-top: 2px; }
  .actions { display: flex; flex-wrap: wrap; gap: 8px; margin: 14px 0; }
  button, .btn {
    background: #1a2330; color: var(--text); border: 1px solid var(--border);
    border-radius: 8px; padding: 8px 14px; font-size: 0.85rem;
    cursor: pointer; font-family: inherit;
  }
  button:hover, .btn:hover { border-color: var(--blue); color: #fff; }
  button.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
  button.primary:hover { filter: brightness(1.1); }
  input[type="text"] {
    background: #0e141b; border: 1px solid var(--border); color: var(--text);
    border-radius: 8px; padding: 8px 12px; font-size: 0.9rem;
    min-width: 180px; flex: 1; font-family: inherit;
  }
  input:focus { outline: none; border-color: var(--blue); }
  .row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
  pre, .out {
    background: #0a0e13; border: 1px solid var(--border); border-radius: 8px;
    padding: 12px; font-family: ui-monospace, "Cascadia Code", monospace;
    font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap;
    max-height: 280px; color: #c5d0de;
  }
  .log { max-height: 220px; }
  .mem-stats { display: flex; flex-wrap: wrap; gap: 12px; font-size: 0.85rem; }
  .mem-stats span { color: var(--muted); }
  .mem-stats strong { color: var(--text); }
  footer {
    margin-top: 24px; padding-top: 12px; border-top: 1px solid var(--border);
    font-size: 0.75rem; color: var(--muted); text-align: center;
  }
  .sys-pill {
    display: inline-block; margin: 2px 4px 2px 0; padding: 2px 8px;
    border-radius: 999px; background: #15202b; border: 1px solid var(--border);
    font-size: 0.75rem; color: var(--blue);
  }
</style>
</head>
<body>
<header>
  <h1>OMNIPRESENT OS <span>v3.30-ALL</span></h1>
  <div class="badge">port :__PORT__ · triad · REV C</div>
</header>
<nav class="tabs">
  <a href="/">Classic</a>
  <a href="/modern" class="active">Modern</a>
</nav>

<div class="wrap">
  <div class="grid">
    <div class="card" style="grid-column: 1 / -1;">
      <h2>Lanes</h2>
      <div id="lanes">Loading…</div>
    </div>

    <div class="card">
      <h2>Systems & Memory</h2>
      <div id="sysmem" class="mem-stats">Scanning…</div>
      <div id="syspills" style="margin-top:10px;"></div>
    </div>

    <div class="card">
      <h2>Quick actions</h2>
      <div class="actions">
        <button class="primary" onclick="doDispatch()">Dispatch</button>
        <button onclick="doSys()">Systems</button>
        <button onclick="doPulse()">Pulse</button>
        <button onclick="doCompress()">Compress</button>
        <button onclick="doSavepoint()">Savepoint</button>
      </div>
      <div class="row" style="margin-top:8px;">
        <input id="mprtext" type="text" placeholder="MPR sample text…" value="stones hitting stones">
        <button onclick="doMpr()">MPR</button>
      </div>
    </div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h2>CAVE-AI</h2>
    <div class="row">
      <input id="chatin" type="text" placeholder="health · systems · compress · dispatch · mpr x · pulse · whoami · help" style="flex:1;">
      <button class="primary" onclick="doChat()">Say</button>
    </div>
    <div id="out" class="out" style="margin-top:10px;">Ready.</div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h2>Live log</h2>
    <pre id="log" class="log">…</pre>
  </div>

  <footer>
    Omnipresent OS · triad absolute build · self-healing · MPR · systems+mem<br>
    Classic UI at <a href="/" style="color:var(--blue)">/</a> · Modern at <a href="/modern" style="color:var(--blue)">/modern</a>
  </footer>
</div>

<script>
const H = {'Content-Type':'text/plain','X-Triad':'1'};

async function tick(){
  try {
    const r = await fetch('/tick');
    const d = await r.json();
    let h = '';
    for (const l of ['rs','c','py']) {
      const s = d.lanes[l] || {};
      const up = !!s.up;
      h += `<div class="lane">
        <div>
          <div class="name">${l.toUpperCase()}</div>
          <div class="meta">${s.repairs||0} repairs${s.detail ? ' · ' + s.detail : ''}</div>
        </div>
        <div class="status ${up?'up':'down'}">${up?'ONLINE':'DOWN'}</div>
      </div>`;
    }
    document.getElementById('lanes').innerHTML = h;

    const m = d.mem || {};
    document.getElementById('sysmem').innerHTML =
      `<span>Log segs <strong>${m.log_segments||0}</strong></span>` +
      `<span>Saved <strong>${m.log_saved||0}</strong> B</span>` +
      `<span>RAM cold <strong>${m.ram_pages_cold||0}</strong></span>` +
      `<span>Shadow <strong>${m.ram_saved||0}</strong> B</span>` +
      `<span>Gzip <strong>${m.gz_hits||0}</strong></span>` +
      `<span>Tasks <strong>${d.tasks||0}</strong></span>`;

    const det = Object.entries(d.sys||{}).filter(([,v])=>v.detected).map(([k])=>k.toUpperCase());
    document.getElementById('syspills').innerHTML = det.length
      ? det.map(x=>`<span class="sys-pill">${x}</span>`).join('')
      : '<span class="sys-pill">standalone</span>';

    document.getElementById('log').textContent = (d.log||[]).slice(-40).join('\\n');
  } catch(e) {
    document.getElementById('lanes').innerHTML = '<div class="meta">UI offline or still booting…</div>';
  }
}

async function doDispatch(){
  document.getElementById('out').textContent = 'Dispatching…';
  const d = await (await fetch('/dispatch')).json();
  document.getElementById('out').textContent =
    `DISPATCH verified=${d.verified}  workers_total=${d.workers_total}`;
}
async function doMpr(){
  const t = document.getElementById('mprtext').value || 'caveman';
  document.getElementById('out').textContent = 'Compressing…';
  const d = await (await fetch('/mpr', {method:'POST', headers:H, body:t})).json();
  let lines = [`MPR identical=${d.identical}  ratio=${d.ratio}`];
  for (const [k,v] of Object.entries(d.lanes||{}))
    lines.push(`${k}: ${v.orig} → ${v.comp}`);
  document.getElementById('out').textContent = lines.join('\\n');
}
async function doSys(){
  const d = await (await fetch('/systems')).json();
  document.getElementById('out').textContent = JSON.stringify(d, null, 2);
}
async function doPulse(){
  const d = await (await fetch('/chat', {method:'POST', headers:H, body:'pulse'})).json();
  document.getElementById('out').textContent = 'CAVE-AI: ' + d.reply;
}
async function doCompress(){
  document.getElementById('out').textContent = 'Compressing (may take a moment)…';
  const d = await (await fetch('/chat', {method:'POST', headers:H, body:'compress'})).json();
  document.getElementById('out').textContent = 'CAVE-AI: ' + d.reply;
}
async function doSavepoint(){
  const d = await (await fetch('/chat', {method:'POST', headers:H, body:'savepoint'})).json();
  document.getElementById('out').textContent = 'CAVE-AI: ' + d.reply;
}
async function doChat(){
  const t = document.getElementById('chatin').value;
  if (!t) return;
  document.getElementById('out').textContent = 'CAVE-AI thinking…';
  const d = await (await fetch('/chat', {method:'POST', headers:H, body:t})).json();
  document.getElementById('out').textContent = 'CAVE-AI: ' + d.reply;
}
document.getElementById('chatin').addEventListener('keydown', e => {
  if (e.key === 'Enter') doChat();
});
setInterval(tick, 2000);
tick();
</script>
</body>
</html>
"""


OPEN_GET = ("/healthz", "/readyz", "/v1.0/healthz")   # probe endpoints: gate-free (booleans only)

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _cors(self):
        # Allow browser UI (file:// or any localhost port) to enter LIVE mode
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Triad, Accept, Accept-Encoding")
        self.send_header("Access-Control-Max-Age", "600")
    def _send(self, b, code, ctype, enc=None):
        self.send_response(code); self.send_header("Content-Type", ctype)
        self._cors()
        if enc: self.send_header("Content-Encoding", enc); MEM["gz_hits"] += 1
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self):
        self.send_response(204); self._cors(); self.end_headers()
    def do_DELETE(self):
        self.send_error(405)
    def do_PUT(self):
        self.send_error(405)
    def _gz(self, b, code, ctype):
        if len(b) > 256 and "gzip" in (self.headers.get("Accept-Encoding") or ""):
            self._send(gzip.compress(b), code, ctype, "gzip")
        else:
            self._send(b, code, ctype)
    def _j(self, obj, code=200): self._gz(json.dumps(obj).encode(), code, "application/json")
    def _t(self, text, code=200, ctype="text/plain; charset=utf-8"): self._gz(text.encode(), code, ctype)
    def _gate(self, post=False):                          # P1-4: real Host gate
        host = (self.headers.get("Host") or "").split(":")[0].lower()
        if host not in ("127.0.0.1", "localhost"):
            self.send_error(403); return False
        if post and self.headers.get("X-Triad") != "1":
            self.send_error(403); return False
        return True
    def do_GET(self):
        if self.path == "/healthz": return self._j({"status": "ok"})                    # k8s liveness
        if self.path == "/readyz":                                                       # k8s readiness
            up = any(ST[l]["up"] for l in ST)
            return self._j({"ready": up, "lanes_up": sum(1 for l in ST if ST[l]["up"])}, 200 if up else 503)
        if self.path == "/v1.0/healthz": return self._j({"appStatus": "healthy"})        # dapr probe
        if not self._gate(): return
        if self.path == "/":
            self._gz(HTML_SOURCE.replace("__PORT__", str(UI_PORT)).encode(), 200, "text/html; charset=utf-8")
        elif self.path == "/modern":
            self._gz(MODERN_HTML.replace("__PORT__", str(UI_PORT)).encode(), 200, "text/html; charset=utf-8")
        elif self.path == "/tick":
            self._j({"lanes": ST, "log": LOG[-50:], "mem": MEM, "tasks": len(TASKS),
                     "sys": systems_scan()})
        elif self.path == "/pulse": self._j({"channels": pulse()})
        elif self.path == "/dispatch": self._j(triad_dispatch())   # P0-B: wired
        elif self.path == "/logfull": self._j({"lines": log_full()})
        elif self.path == "/metrics": self._t(metrics_text(), 200, "text/plain; version=0.0.4")
        elif self.path == "/systems": self._j(systems_scan())
        elif self.path == "/tasks": self._j({"tasks": TASKS[-50:]})
        elif self.path.startswith("/eb/"): self._j({"topic": self.path[4:], "events": EB.get(self.path[4:], [])})
        else: self.send_error(404)
    def do_POST(self):
        if not self._gate(post=True): return
        n = int(self.headers.get("Content-Length") or 0)
        if n < 0: n = 0
        if n > 2_000_000:  # hard ceiling — reject absurd bodies
            self.send_error(413); return
        raw = self.rfile.read(n)
        # GLITCH-HARDEN: never crash connection on non-UTF8 / null bytes
        body = raw.decode("utf-8", errors="replace")
        try:
            if self.path == "/chat":
                self._j({"reply": cave_chat(SCRUB.sub("[scrubbed]", body))})
            elif self.path == "/kill":
                try:
                    l = json.loads(body)["lane"]
                    if l in ("rs", "c", "py"):
                        kill_lane(l); self._j({"ok": True, "lane": l})
                    else:
                        self._j({"ok": False, "err": "unknown lane"})
                except Exception:
                    self._j({"ok": False})
            elif self.path == "/mpr":
                # Prefer raw bytes for codec fidelity; cap 16KB
                self._j(triad_mpr(raw[:16384]))
            elif self.path.startswith("/eb/"):
                eb_publish(self.path[4:], body); self._j({"ok": True})
            else:
                self.send_error(404)
        except Exception as e:
            klog(f"[HTTP] POST {self.path} glitch contained: {repr(e)[:120]}")
            try: self._j({"ok": False, "err": "handler_exception"})
            except Exception: pass

def _port_override():
    if "--port" in sys.argv:
        try:
            return int(sys.argv[sys.argv.index("--port") + 1])
        except (ValueError, IndexError):
            klog("[PORT] bad --port value — ignoring")
    nom = os.environ.get("NOMAD_PORT_ui", "")
    if nom.isdigit():
        klog(f"[PORT] Nomad dynamic port detected (NOMAD_PORT_ui={nom}) — trying first")
        return int(nom)
    return 0

def bind_ui():
    global UI_PORT
    ov = _port_override()
    for p in ((ov,) if ov else ()) + PORTS + (0,):
        if p:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.25)
                if s.connect_ex(("127.0.0.1", p)) == 0:
                    klog(f"[PORT] 127.0.0.1:{p} busy (a service is listening) — skipping politely")
                    continue
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), H)
            UI_PORT = srv.server_address[1]
            if p == 0:
                klog(f"[PORT] all preferred ports busy — OS assigned 127.0.0.1:{UI_PORT}")
            else:
                klog(f"[PORT] bound 127.0.0.1:{UI_PORT}")
            return srv
        except OSError as e:
            klog(f"[PORT] 127.0.0.1:{p} unavailable ({e}) — trying next")
    klog("[FATAL] cannot bind any port on 127.0.0.1 — check firewall/permissions")
    raise SystemExit(1)

def _ensure_build_dir():
    global BUILD, SAVEPOINTS, SETUP_DIR, MPRDIR, SRCP, BINP
    try:
        BUILD.mkdir(parents=True, exist_ok=True)
        return
    except OSError as e:
        alt = Path(tempfile.gettempdir()) / "omnipresent_build"
        alt.mkdir(parents=True, exist_ok=True)
        klog(f"[BUILD] '{BUILD}' not writable ({repr(e)[:80]}) — fallback build root: {alt}")
        BUILD = alt; SAVEPOINTS = alt / "savepoints"; SETUP_DIR = alt / "setup"; MPRDIR = alt / "mpr"
        SRCP = {"c": alt / "tau_os.c", "rs": alt / "tau_os.rs", "py": alt / "tau_os.py"}
        BINP = {"c": alt / ("tau_os_c" + EXT), "rs": alt / ("tau_os_rs" + EXT), "py": alt / "tau_os_py.pyc"}

def main():
    global _POOL
    _ensure_build_dir()                                   # BUNDLE: run even if disk path is locked down
    make_savepoint("boot")                                # backup save point BEFORE any repair
    klog("v3.30-ALL (REV D: COMBINED v3.26 UI + TRIAD/MPR/SYSTEMS) ONLINE")
    emit_setup_scripts()                                  # BUNDLE: installers on disk, always
    toolchain_audit()                                     # BUNDLE: what's missing, + PATH surface (win)
    sysdet = systems_scan()
    det = [k for k, v in sysdet.items() if v["detected"]]
    klog(f"[SYSTEMS] detected: {det or ['(no external orchestrator — standalone triad)']}")
    # Bind UI FIRST so browser Launcher can enter LIVE mode while lanes compile
    srv = bind_ui()
    klog(f"UI ONLINE (early): http://127.0.0.1:{UI_PORT}  — /healthz live; lanes still booting")
    def _boot_lanes():
        global _POOL
        try:
            try: _POOL = Pool(24)
            except Exception: klog("Pool failed - fallback to single-thread")
            for lane in ("rs", "c", "py"):
                try: boot_lane(lane)
                except Exception as e: klog(f"[BOOT] lane {lane} error: {repr(e)[:120]}")
            if ST["py"]["up"] and not py_selftest():
                ST["py"].update(up=False, detail="selftest fail", last_err="selftest fail")
            if all(ST[l]["up"] for l in ("c", "rs")):
                try: klog(f"[TRIAD] boot cross-check identical={triad_mpr(PAYLOAD)['identical']}")
                except Exception as e: klog(f"[TRIAD] cross-check err: {repr(e)[:80]}")
            try: make_bundle("boot")
            except Exception as e: klog(f"[BUNDLE] {repr(e)[:80]}")
            klog("[BOOT] lane boot sequence finished")
        except Exception as e:
            klog(f"[BOOT] fatal: {repr(e)[:160]}")
    threading.Thread(target=_boot_lanes, daemon=True).start()
    threading.Thread(target=memthread, daemon=True).start()     # dynamic compression
    threading.Thread(target=watchdog, daemon=True).start()
    klog(f"UI ONLINE: http://127.0.0.1:{UI_PORT}")
    srv.serve_forever()

if __name__ == "__main__":
    main()