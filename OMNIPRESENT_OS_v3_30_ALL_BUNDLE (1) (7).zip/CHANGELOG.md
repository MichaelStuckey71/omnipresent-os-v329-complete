
## Real-mode policy (v3.29.2+)

- Launcher / Triad / Systems / live MPR: **no simulated online status**. Offline = offline.
- Requires real `python3 omnipresent_os_v329_3.py` with CORS + early bind.
- Client-side MPR Lab JS codec is **real compress/verify in browser** (labeled).
- Caveman is a **local rule engine**, labeled as such (not a neural model).
- Summed AI Generate Code is a **local template stub**, labeled (use providers/keys for real multi-model).
- Free AI tiles open real third-party sites only when you explicitly opt in.

# OMNIPRESENT OS v3.29.3-ALL — CHANGELOG

## v3.30-ALL — version bump + bundle consolidation

Renamed `omnipresent_os_v329_3.py` → `omnipresent_os_v330_all.py`, all internal
version strings bumped `3.29.3-ALL` → `3.30-ALL` (title, boot banner, lane-build
comments, toolchain-setup script headers, portable-bundle text). HTML renamed
to `Omnipresent_OS_v3.30-ALL.html` with matching version strings and its
`python3 omnipresent_os_v329_3.py` instructions updated to the new filename.
No code/logic change beyond the rename — the MPR search-window fix and
`roundtrip_ok` field from the previous patch carry over unchanged, re-verified
live after the rename (16KB adversarial payload ~0.86s, `identical=True`,
`roundtrip_ok=True`).

Bundle consolidated to a single copy of the supervisor script (the previous
`omnipresent_os_v329_3_2.py` duplicate twin is dropped — one canonical file
only), packaged together with `tau_bridge.py` and a PDF checksum manifest in
one archive.

## v3.29.3-ALL (patch) — MPR search-window hang regression fixed (verified by running it)

`omnipresent_os_v329_3.py` / `omnipresent_os_v329_3_2.py`: the real lane sources
(C, Rust, embedded Python) had reverted to the unbounded `WIN=65535` match-search
window in `mpr_compress()`. Confirmed live: a 16KB random payload to `/mpr` took
13.65s. Re-applied the `SRCH=512` search-window cap (distinct from `WIN`, which
still governs max encodable distance and is unchanged) identically across all
three lane sources, so cross-lane `identical=` stays byte-exact. Also restored
the `roundtrip_ok` field on `/mpr` (verifies the decompressed bytes against the
actual original, not just that lanes agree with each other), which had been
dropped from `triad_mpr()` in this build. Re-verified: 16KB adversarial payload
now ~0.8s, full fuzz suite (empty/full-byte-range/random/repetitive/16KB) all
`identical=True roundtrip_ok=True`, all pre-existing endpoints still pass
(healthz/readyz/metrics/systems/tick/tasks/dispatch/pulse/chat/kill).
See the corrected note in `validate_and_start.md`.


## v3.29.3-ALL (patch) — Summon "openTiles" inverted-logic fix

Root cause: `omniSummon()`'s fallback `openTiles` check (used by the main
"Summon All + Sum" button and per-tab mini-dock "Summon All" button — the
only two callers NOT covered by the `apisOnly/noTiles/fromDock` short-circuit
below it) used a double-negation that inverted the **Open free AI tabs**
checkbox: `!(!checkbox||checkbox.checked)` evaluates to `true` when the box
is UNCHECKED and `false` when CHECKED — backwards from the label and from
the v3.29.2 "default OFF" intent. This is why ChatGPT tabs kept popping
open on Summon even though the checkbox was off, drowning out the Caveman
routing output that was actually being written correctly underneath.

Fix: `openTiles=!!(document.getElementById('omniOpenTiles')&&document.getElementById('omniOpenTiles').checked);`
— now a direct (non-inverted) read of the checkbox state.

## v3.29.2-ALL (2026-09-02) — Summing / ChatGPT fan-out hard fix

Root cause: `omniSummon({fromDock:true})` still honored **Open free AI tabs** (checked by default), so Caveman Dock Send / Summon and Summed AI paths called `fanOut()` → `window.open(chatgpt.com)`.

Fixes:
- Dock **Summon** and **dockSend** use `{fromDock:true, apisOnly:true, noTiles:true}`
- `openTiles` forced **off** when `fromDock`, `apisOnly`, `noTiles`, or active **Summed AI** tab
- Multitask auto-queue skipped on dock/Summed path (avoids second `fanOut` via `runOne`)
- **Open free AI tabs** checkbox default **OFF** (opt-in only on Web AI / Summon All)
- Summed AI tab still opens Caveman Dock only



## v3.29.1-ALL (2026-09-02) — patch

- **FIX:** Summed AI tab no longer opens ChatGPT / free tiles.
- Selecting **Summed AI** opens the **Caveman Dock** and mirrors the coordinator prompt.
- Tab mini-dock on Summed AI routes local/Caveman only (no `omniSummon` fan-out).
- `summedGen()` mirrors coder output into Caveman Dock.
- Unified `switchTab` (original + additive hooks).
- Bundle repackaged as **v3.29.1-ALL**.



**Build date:** 2026-09-02  
**Lineage:** v3.26-SYNC (HTML) + v3.28.1-CAVEMAN (Python triad) → v3.29.1-ALL (combined)  
**Policy:** v3.26 UI/aesthetic/features LOCKED. This release only ADDS and FIXES — nothing from v3.26 was removed or rewritten.

## What v3.29.1-ALL is

A single combined build that keeps every v3.26 feature exactly as-is and layers in the v3.28 triad/MPR/systems concepts as new tabs, plus a Launcher that starts all 3 TAU cores (p · c · r) and Omnipresent correctly.

## Files in this build

1. `Omnipresent_OS_v3.29.1-ALL.html` — the combined UI (15 tabs, dual-mode: works standalone in-browser OR talks to the live Python supervisor)
2. `omnipresent_os_v329.py` — the combined Python supervisor (v3.28 dual-UI triad + MPR + systems + dynamic compression), serving the combined HTML
3. `omnipresent-os-v3-29-all-architecture.png` — system diagram
4. `CHANGELOG.md` — this file

## v3.26 features kept UNTOUCHED (do-not-drift list)

All present and unchanged in v3.29:

- 🖥️ Console — boot checker + TAU multi-core panel
- 🧪 Code Runner — sandboxed JS iframe + Caveman AI offline
- 📐 Professor Math — derivatives, integrals, algebra, trig + Caveman/Recon
- 👁️ Vision Bridge — ASCII schematic + features + spatial notes + prompt block, auto training set
- 💬 Web AI Apps — 24 free chat tiles + fan-out + Sum All consensus/diff
- ⚙️ Multi-Task — parallel queue (code / math / AI / wait)
- 🤖 Summed AI — Coordinator + Coder → VFS / Editor
- 📁 File System — VFS tree, editor, upload, ZIP, JSON import/export, meter
- ⚙️ Compiler — JS sandbox / Pyodide / Piston / HTML preview + templates
- 🔑 Key Vault — per-provider slots, bulk parse, drag-drop keys + API Key Wizard + Unified Key
- ⚡ API Providers — GLM / Groq / OpenRouter / Nemotron / … keyed calls + 3× Parallel + burst auto-tune
- 🟢 Nemotron Free Chatbot — server hook-up (OpenRouter free / NIM)
- 🚀 Omni Summon — all AIs, one question, sum answers
- 📁 File Dock — 100 files, drag-drop, convert, attach to master chat
- 💬 Caveman Dock — horizontal master chat, every tab, prompt-tie
- ⚡ Real-time Sync — BroadcastChannel + WebSocket + streaming AI
- 🛡 Firewall / Proxy / Cloud / Cache / Memory — full settings suite
- ⏻ Soft Shutdown — state JSON + VFS persist + resume
- 💬 Chat persistence — dock/omni/api/nemo/vision auto-save to localStorage

## NEW in v3.29.1-ALL (additive only)

### 🚀 Launcher tab (default open)
- One "Start Everything" button: probes the Python supervisor → loads TAU p·c·r cores → runs boot check → arms triad + systems.
- Step-by-step startup guide.
- Live core status (p · c · r) + subsystem checklist (supervisor, VFS, 24 AI tiles, docks, sync, MPR codec).
- Quick-link buttons to every major drop-box.

### 🦴 Triad Supervisor tab
- Browser mirror of the v3.28 Python triad (RUST + C + PYTHON self-healing).
- Dual-mode: live when the Python supervisor is running (reads `/tick`), simulated otherwise.
- Dispatch (24-way FNV-1a), lane sabotage + watchdog rebuild (let-it-crash / one_for_one).
- Connect/refresh; cross-checks lane up/repairs/workers with the supervisor.

### 📦 MPR Lab tab
- Pure-JS port of the v3.28 MPR (Match-Position-Run) codec — exact byte-format parity (MPR1 header, u32 little-endian, SRCH=512 cap, MAXL=66, MINL=3).
- Pick ANY file → compress → verify roundtrip against the exact original bytes.
- Cross-check vs the live supervisor's C/Rust/Python lanes over `/mpr` when running.

### 🧠 Systems + Mem tab
- Mirror of the v3.28 systems manager: Kubernetes / Dapr / Nomad / Temporal / Ray / Vert.x / Erlang-OTP detection.
- Dynamic compression memory stats (cold log archive, TAU-RAM shadow pages, gzip hits, task ledger).
- Endpoint reference (`/healthz`, `/readyz`, `/v1.0/healthz`, `/metrics`, `/systems`, `/tasks`, `/eb/`, `/kill`).

## Dual-mode operation

- **Standalone:** open the HTML in a browser — all v3.26 features work; triad/MPR/systems run in-browser simulated mode.
- **With supervisor:** run `python omnipresent_os_v329.py` — the HTML auto-detects it on `:9000` and switches triad/MPR/systems tabs to LIVE mode, cross-checking against the real C/Rust/Python lanes.

## Bugfixes / stability (v3.29, additive)

These were applied without altering v3.26 logic — only guardrails and additive hardening:

- **MPR search window cap (SRCH=512):** the v3.28 triad had an unbounded brute-force match search (was WIN=65535) that hung on adversarial/high-entropy input near the 16KB endpoint cap. The JS port uses the same capped window, so the lab never hangs.
- **/mpr raw-bytes route:** the v3.28 supervisor keeps raw bytes on `/mpr` (no lossy UTF-8 round-trip) and caps at 16384 bytes. The HTML cross-check honors this.
- **Launcher default tab:** the Launcher is now the first tab and opens by default, so users land on a single entry point instead of the raw console.
- **No v3.26 function renamed or removed:** all original function names, IDs, and localStorage keys (`opos_vfs`, `opos_keys`, `opos_chat`, `opos_unified_key`) are preserved for backward compatibility with existing saved state.

## How to run

### Standalone (browser only)
1. Open `Omnipresent_OS_v3.29.1-ALL.html` in a browser (or serve: `python -m http.server 8080`).
2. The Launcher tab opens. Press **Start Everything**.
3. Use any AI drop-box.

### Full (with live triad supervisor)
1. `python omnipresent_os_v329.py` — starts the triad on `:9000` (port cascade if busy).
2. Open the HTML (served over HTTP recommended for full API/CORS).
3. The Triad/MPR Lab/Systems tabs now show live data and cross-check against C/Rust/Python lanes.

## Compatibility (AI drop-boxes)

v3.29 keeps all of v3.26's AI drop-boxes working together as one compatible surface:

- File Dock (100 files, any type → text for AIs) ↔ Caveman Dock (master chat) ↔ 24 free AI tiles ↔ API providers (GLM/Groq/OpenRouter/Nemotron, 3× Parallel) ↔ Omni Summon (sum consensus) ↔ Vision Bridge (packets for non-vision AIs).
- Prompts are tied (`syncAllPrompts`) across all boxes, so dropping content into any one propagates to the rest.
- File Dock attachments become "Universal Context" readable by every AI (free tile or keyed API).

## Fingerprints

- HTML lineage: v3.26-SYNC → v3.29.1-ALL
- Python lineage: v3.28.1-CAVEMAN (REV C: SYSTEMS+MEM, dual-UI) → v3.29.1-ALL
- TAU cores: p✓ c✓ r✓
- No-drift policy: v3.20 feature lock retained.
