#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tau_bridge.py — triad lane resolver + watchdog supervisor (OMNIPRESENT OS v3.29)

  RUST lane    tau_os.rs  → rustc    → self-healing
  C lane       tau_os.c   → cc/gcc   → heartbeat worker (POSIX)
  PYTHON lane  tau_os.py  → python   → single source of truth (MATERIALIZED if absent)
  Watchdog     let-it-crash → one_for_one rebuild every 2s
  Ports        --port → NOMAD_PORT_ui → 9000 → 8327 → …
  Endpoints    /health /healthz /readyz /v1/_healthz /tick /tasks
               /eb/topics /systems /metrics (Prometheus) — CORS open

"crust bridge tau not found" is fixed here: lanes are RESOLVED, missing ones
are built or materialized, and boot NEVER dies from a missing lane.

Use:
  python tau_bridge.py --scan      diagnose: which lanes/compilers/ports exist → exit
  python tau_bridge.py             run the triad supervisor standalone
  python tau_bridge.py --port 9000

Two-line patch into omnipresent_os_v329.py (top of its boot function):
  import tau_bridge
  tau_bridge.ensure_lanes(verbose=True)   # place BEFORE your tau lookup
"""
import argparse, json, os, shutil, socket, subprocess, sys, threading, time
import urllib.parse
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "3.29.3-bridge"
HERE = os.path.dirname(os.path.abspath(__file__))
T0 = time.time()
EXE = ".exe" if os.name == "nt" else ""
PRUNE = {".git", "node_modules", "__pycache__", ".cache", "venv", ".venv",
         "AppData", "Library", ".cargo", ".rustup", ".vscode",
         "anaconda3", "miniconda3", ".conda"}

# ------------------------------------------------- embedded lane sources
SRC_PY = r'''#!/usr/bin/env python3
"""tau_os.py - PYTHON lane, single source of truth (materialized by tau_bridge)"""
import hashlib, json, os, sys, threading, time

def handle(line):
    line = line.strip()
    if line == "crash":
        os._exit(1)                      # let-it-crash -> watchdog rebuilds
    if line.startswith("task "):
        h = hashlib.sha256()
        for _ in range(50_000):
            h.update(line[5:].encode("utf-8", "replace"))
        print(json.dumps({"lane": "python", "event": "result",
                          "hash": h.hexdigest()[:16]}), flush=True)

def stdin_loop():
    for line in sys.stdin:
        handle(line)

print(json.dumps({"lane": "python", "event": "up", "pid": os.getpid()}), flush=True)
threading.Thread(target=stdin_loop, daemon=True).start()
tick = 0
while True:
    tick += 1
    print(json.dumps({"lane": "python", "event": "tick", "tick": tick,
                      "ts": round(time.time(), 3)}), flush=True)
    time.sleep(1.0)
'''

SRC_RS = r'''// tau_os.rs - RUST lane, self-healing (materialized default by tau_bridge)
use std::io::{self, BufRead, Write};
use std::sync::mpsc;
use std::thread;
use std::time::Duration;

fn fnv1a(s: &str) -> u64 {
    let mut h: u64 = 1469598103934665603;
    for b in s.as_bytes() { h ^= *b as u64; h = h.wrapping_mul(1099511628211); }
    h
}

fn main() {
    let (tx, rx) = mpsc::channel::<String>();
    thread::spawn(move || {
        let stdin = io::stdin();
        for line in stdin.lock().lines() {
            if line.is_err() { break; }
            if tx.send(line.unwrap()).is_err() { break; }
        }
    });
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let mut tick: u64 = 0;
    println!("{{\"lane\":\"rust\",\"event\":\"up\"}}");
    loop {
        tick += 1;
        let _ = writeln!(out, "{{\"lane\":\"rust\",\"event\":\"tick\",\"tick\":{}}}", tick);
        let _ = out.flush();
        while let Ok(line) = rx.try_recv() {
            let l = line.trim().to_string();
            if l == "crash" { std::process::exit(1); }
            if let Some(t) = l.strip_prefix("task ") {
                let _ = writeln!(out, "{{\"lane\":\"rust\",\"event\":\"result\",\"hash\":\"{:016x}\"}}", fnv1a(t));
                let _ = out.flush();
            }
        }
        thread::sleep(Duration::from_secs(1));
    }
}
'''

SRC_C = r'''/* tau_os.c - C lane, materialized default by tau_bridge (POSIX) */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/select.h>

static uint64_t fnv1a(const char *s) {
    uint64_t h = 1469598103934665603ULL;
    while (*s) { h ^= (unsigned char)*s++; h *= 1099511628211ULL; }
    return h;
}

int main(void) {
    long tick = 0;
    char line[512];
    setvbuf(stdout, NULL, _IOLBF, 0);
    puts("{\"lane\":\"c\",\"event\":\"up\"}");
    for (;;) {
        tick++;
        printf("{\"lane\":\"c\",\"event\":\"tick\",\"tick\":%ld}\n", tick);
        fd_set rfds; struct timeval tv = {0, 0};
        FD_ZERO(&rfds); FD_SET(0, &rfds);
        while (select(1, &rfds, NULL, NULL, &tv) > 0 && fgets(line, sizeof line, stdin)) {
            line[strcspn(line, "\r\n")] = 0;
            if (strcmp(line, "crash") == 0) return 1;
            if (strncmp(line, "task ", 5) == 0)
                printf("{\"lane\":\"c\",\"event\":\"result\",\"hash\":\"%016llx\"}\n",
                       (unsigned long long)fnv1a(line + 5));
            FD_ZERO(&rfds); FD_SET(0, &rfds);
            tv.tv_sec = 0; tv.tv_usec = 0;
        }
        sleep(1);
    }
}
'''

FAVICON = (b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">'
           b'<rect width="32" height="32" fill="#0c0d09"/>'
           b'<rect x="7" y="7" width="18" height="18" fill="none" stroke="#f2a71b" stroke-width="2"/></svg>')

PAGE = """<!doctype html><html><head><meta charset="utf-8"><title>tau triad supervisor</title>
<style>body{background:#0c0d09;color:#e4e0cd;font:14px/1.6 monospace;max-width:720px;margin:40px auto;padding:0 20px}
a{color:#f2a71b}h2{color:#a3d157}</style></head><body>
<h2>tau triad supervisor &mdash; REAL mode</h2>
<p>lanes &middot; p (PYTHON) &middot; c (C) &middot; r (RUST) &mdash; watchdog one_for_one / 2s</p>
<p><a href="/health">/health</a> &middot; <a href="/tick">/tick</a> &middot; <a href="/tasks">/tasks</a>
&middot; <a href="/metrics">/metrics</a> &middot; <a href="/healthz">/healthz</a>
&middot; <a href="/readyz">/readyz</a> &middot; <a href="/systems">/systems</a> &middot; <a href="/eb/topics">/eb/topics</a></p>
<p>POST /tasks {'"text":"..."'} routes real work to every live lane.</p>
</body></html>"""

# ------------------------------------------------------------------ state
class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.lanes = {}
        self.tick = 0
        self.ledger = deque(maxlen=100)
        self.events = {"tick": 0}
        self.logbuf = deque(maxlen=200)

    def log(self, src, msg):
        line = f"[{time.strftime('%H:%M:%S')}] [{src}] {msg}"
        with self.lock:
            self.logbuf.append(line)
        print(line, flush=True)

STATE = State()

# ------------------------------------------------------------------- lane
class Lane:
    def __init__(self, key, name, argv, origin):
        self.key, self.name, self.argv, self.origin = key, name, argv, origin
        self.proc, self.restarts, self.ticks = None, 0, 0
        self.last_result, self.reason = None, None
        self.restart_ts = deque(maxlen=20)
        self.flapping = False

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self):
        if not self.argv:
            return
        try:
            self.proc = subprocess.Popen(
                self.argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1, errors="replace")
        except OSError as e:
            self.reason = str(e)
            STATE.log(self.key, f"spawn failed: {e}")
            return
        self.reason = None
        threading.Thread(target=self._reader, daemon=True, name=f"read-{self.key}").start()
        STATE.log(self.key, f"up · pid {self.proc.pid} · {self.origin}")

    def _reader(self):
        for line in self.proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                j = json.loads(line)
            except ValueError:
                STATE.log(self.key, f"out: {line[:80]}")
                continue
            ev = j.get("event")
            if ev == "tick":
                self.ticks = j.get("tick", self.ticks + 1)
            elif ev == "result":
                self.last_result = j.get("hash")
                with STATE.lock:
                    STATE.ledger.append({"lane": self.key, "hash": j.get("hash"),
                                         "ts": round(time.time(), 3)})
        # stdout closed → process is gone; the watchdog rebuilds

    def send(self, text):
        if not self.alive() or not self.proc.stdin:
            return False
        try:
            self.proc.stdin.write(text + "\n")
            self.proc.stdin.flush()
            return True
        except (OSError, ValueError):
            return False

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except OSError:
                pass

    def snapshot(self):
        online = self.alive()
        return {"name": self.name, "state": "online" if online else "offline",
                "origin": self.origin, "ticks": self.ticks,
                "restarts": self.restarts, "flapping": self.flapping,
                "pid": self.proc.pid if online else None,
                "reason": self.reason, "last_result": self.last_result}

# --------------------------------------------------------------- watchdog
def watchdog_loop():
    while True:
        time.sleep(2.0)                       # one_for_one rebuild every 2s
        for lane in list(STATE.lanes.values()):
            if not lane.argv:                 # nothing runnable → honestly offline
                continue
            if not lane.alive():
                if lane.proc is not None:     # it crashed → let-it-crash, rebuild
                    lane.restarts += 1
                    lane.restart_ts.append(time.time())
                    recent = [t for t in lane.restart_ts if time.time() - t < 60]
                    lane.flapping = len(recent) >= 6
                    STATE.log(lane.key, f"crashed → one_for_one rebuild #{lane.restarts}"
                              + (" (FLAPPING)" if lane.flapping else ""))
                lane.start()

def tick_loop():
    while True:
        time.sleep(1.0)
        with STATE.lock:
            STATE.tick += 1
            STATE.events["tick"] += 1

# ------------------------------------------------------------ scan + heal
def port_free(port, host="127.0.0.1"):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((host, port)); return True
        except OSError:
            return False

def _find(names, roots, seconds):
    wanted = {n.lower() for n in names if n}
    hits, deadline = [], time.time() + seconds
    for root in roots:
        if not os.path.isdir(root):
            continue
        try:
            for dirpath, dirnames, filenames in os.walk(root):
                if time.time() > deadline:
                    return hits
                dirnames[:] = [d for d in dirnames if d not in PRUNE]
                for f in filenames:
                    if f.lower() in wanted:
                        hits.append(os.path.join(dirpath, f))
                        if len(hits) >= 10:
                            return hits
        except OSError:
            continue
    return hits

def scan(full=False):
    roots = [HERE, os.getcwd()]
    if full:
        roots.append(os.path.expanduser("~"))
    dl = 12 if full else 3
    r = {"time": datetime.now().astimezone().isoformat(timespec="seconds"),
         "here": HERE, "python": sys.executable,
         "sources": {}, "binaries": {}, "compilers": {}, "ports": {}}
    r["sources"]["tau_os.py"] = _find(["tau_os.py"], roots, dl)
    r["sources"]["tau_os.rs"] = _find(["tau_os.rs"], roots, dl)
    r["sources"]["tau_os.c"]  = _find(["tau_os.c"], roots, dl)
    r["binaries"]["rust"] = _find(["tau_os_rust" + EXE, "tau_os" + EXE], [HERE, os.getcwd()], 1)
    r["binaries"]["c"]    = _find(["tau_os_c" + EXE], [HERE, os.getcwd()], 1)
    for cc in ("rustc", "gcc", "cc", "clang"):
        r["compilers"][cc] = shutil.which(cc)
    for p in (9000, 8327):
        r["ports"][str(p)] = port_free(p)
    r["NOMAD_PORT_ui"] = os.environ.get("NOMAD_PORT_ui")
    return r

def ensure_lanes(verbose=False):
    """THE fix for 'crust bridge tau not found': resolve → build → materialize. Never raises."""
    rep = scan(full=False)
    v = (lambda *a: print(*a, flush=True)) if verbose else (lambda *a: None)
    made = []

    # p · PYTHON lane — single source of truth: must exist
    pys = rep["sources"]["tau_os.py"]
    if pys:
        p_path, p_origin = pys[0], "found:" + os.path.dirname(p_path)
    else:
        p_path = os.path.join(HERE, "tau_os.py")
        with open(p_path, "w", encoding="utf-8") as f:
            f.write(SRC_PY)
        p_origin, made = "materialized-default", made + [p_path]
        v("python lane missing → MATERIALIZED tau_os.py (single source of truth)")
    lanes = {"p": Lane("p", "PYTHON", [sys.executable, p_path], p_origin)}

    # r · RUST lane — compile if source + rustc, else honest offline
    rs = rep["sources"]["tau_os.rs"]
    rbin = (rep["binaries"]["rust"] or [None])[0]
    if rs and not rbin and rep["compilers"].get("rustc"):
        cand = os.path.join(HERE, "tau_os_rust" + EXE)
        try:
            subprocess.run([rep["compilers"]["rustc"], "-O", rs[0], "-o", cand],
                           capture_output=True, timeout=180)
        except Exception:
            cand = None
        rbin = cand if cand and os.path.isfile(cand) else None
    if not rs and not rbin and rep["compilers"].get("rustc"):
        src = os.path.join(HERE, "tau_os.rs")
        with open(src, "w", encoding="utf-8") as f:
            f.write(SRC_RS)
        made.append(src)
        cand = os.path.join(HERE, "tau_os_rust" + EXE)
        try:
            subprocess.run([rep["compilers"]["rustc"], "-O", src, "-o", cand],
                           capture_output=True, timeout=180)
        except Exception:
            cand = None
        rbin = cand if cand and os.path.isfile(cand) else None
    if rbin:
        lanes["r"] = Lane("r", "RUST", [rbin], "binary:" + rbin)
    else:
        l = Lane("r", "RUST", None, "absent")
        l.reason = "no tau_os.rs and no rustc — install rustc or drop tau_os.rs beside the supervisor"
        lanes["r"] = l

    # c · C lane — compile (POSIX) if possible, else honest offline
    cs = rep["sources"]["tau_os.c"]
    cbin = (rep["binaries"]["c"] or [None])[0]
    cc = rep["compilers"].get("gcc") or rep["compilers"].get("cc") or rep["compilers"].get("clang")
    if not cs and not cbin and os.name != "nt":
        csrc = os.path.join(HERE, "tau_os.c")
        with open(csrc, "w", encoding="utf-8") as f:
            f.write(SRC_C)
        made.append(csrc)
        cs = [csrc]
    if not cbin and cs and cc and os.name != "nt":
        cand = os.path.join(HERE, "tau_os_c")
        try:
            subprocess.run([cc, "-O2", cs[0], "-o", cand, "-lpthread"],
                           capture_output=True, timeout=120)
        except Exception:
            cand = None
        cbin = cand if cand and os.path.isfile(cand) else None
    if cbin:
        lanes["c"] = Lane("c", "C", [cbin], "binary:" + cbin)
    else:
        l = Lane("c", "C", None, "absent")
        l.reason = ("no tau_os.c toolchain on Windows — drop a compiled tau_os_c.exe beside the supervisor"
                    if os.name == "nt" else "no cc/gcc/clang found — install a C compiler and restart")
        lanes["c"] = l

    with STATE.lock:
        STATE.lanes = lanes
    for k, l in lanes.items():
        if l.argv:
            l.start()
        else:
            STATE.log(k, f"offline · {l.reason}")
    if made:
        STATE.log("bridge", "crust bridge tau: materialized " + ", ".join(os.path.basename(m) for m in made))
    STATE.log("bridge", "crust bridge tau → RESOLVED (boot cannot die from missing lanes)")
    return made

# ----------------------------------------------------------------- health
def health():
    with STATE.lock:
        lanes = {k: l.snapshot() for k, l in STATE.lanes.items()}
        tick = STATE.tick
        ledger_n = len(STATE.ledger)
    up = sum(1 for l in lanes.values() if l["state"] == "online")
    return {"service": "tau-triad-supervisor", "version": VERSION, "mode": "REAL",
            "supervisor": "online", "all_cores_online": up == 3,
            "time": datetime.now().astimezone().isoformat(timespec="seconds"),
            "uptime_s": round(time.time() - T0), "tick": tick,
            "cores": lanes, "lanes": lanes,      # p=PYTHON · c=C · r=RUST
            "bridges": {"tau": {"status": "bridged", "lanes_up": up, "lanes_total": 3,
                                "note": "crust bridge tau = lane resolution layer"}},
            "tasks_done": ledger_n,
            "log": list(STATE.logbuf)[-24:]}

def metrics():
    h = health()
    out = ["tau_up 1", f"tau_uptime_seconds {h['uptime_s']}", f"tau_tick {h['tick']}"]
    for k, l in h["lanes"].items():
        out.append(f'tau_lane_up{{lane="{l["name"]}"}} {1 if l["state"] == "online" else 0}')
        out.append(f'tau_lane_ticks{{lane="{l["name"]}"}} {l["ticks"]}')
        out.append(f'tau_lane_restarts{{lane="{l["name"]}"}} {l["restarts"]}')
    return "\n".join(out) + "\n"

# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, ctype, body):
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, "application/json; charset=utf-8",
                   json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self._send(204, "text/plain", b"")

    def do_GET(self):
        p = urllib.parse.urlsplit(self.path).path
        if p in ("/health", "/status"):
            self._json(health())
        elif p in ("/healthz", "/v1/_healthz"):
            self._json({"status": "ok"})
        elif p == "/readyz":
            h = health()
            ok = all(l["state"] == "online" for l in h["lanes"].values())
            self._json({"ready": ok, "lanes": {k: l["state"] for k, l in h["lanes"].items()}},
                       200 if ok else 503)
        elif p == "/tick":
            with STATE.lock:
                t = STATE.tick
            self._json({"tick": t, "ts": round(time.time(), 3), "hz": 1})
        elif p == "/tasks":
            with STATE.lock:
                led = list(STATE.ledger)[-50:]
            self._json({"ledger": led})
        elif p == "/eb/topics":
            with STATE.lock:
                ev = dict(STATE.events)
            self._json({"topics": {"tick": {"published": ev["tick"]},
                                   "task.result": {"published": len(STATE.ledger)}}})
        elif p == "/systems":
            q = {"pid": os.getpid(), "python": sys.version.split()[0],
                 "threads": threading.active_count(),
                 "lanes": {k: l.snapshot() for k, l in STATE.lanes.items()}}
            if hasattr(os, "getloadavg"):
                try:
                    q["loadavg"] = [round(x, 2) for x in os.getloadavg()]
                except OSError:
                    pass
            self._json(q)
        elif p == "/metrics":
            self._send(200, "text/plain; charset=utf-8", metrics().encode("utf-8"))
        elif p == "/favicon.ico":
            self._send(200, "image/svg+xml", FAVICON)
        elif p == "/":
            self._send(200, "text/html; charset=utf-8", PAGE.encode("utf-8"))
        else:
            self._json({"ok": False, "error": "not found"}, 404)

    def do_POST(self):
        p = urllib.parse.urlsplit(self.path).path
        if p != "/tasks":
            self._json({"ok": False, "error": "unknown endpoint"}, 404)
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            text = (json.loads(self.rfile.read(n).decode("utf-8") or "{}").get("text") or "").strip()[:200]
        except Exception:
            text = ""
        if not text:
            self._json({"ok": False, "error": "empty"}, 400)
            return
        routed = [k for k, l in STATE.lanes.items() if l.send("task " + text)]
        self._json({"ok": True, "routed": routed, "note": "results land in the /tasks ledger"})

    def log_message(self, *a):
        pass

# ------------------------------------------------------------------- boot
def pick_port(requested):
    cands = ([requested] if requested else [])
    env = os.environ.get("NOMAD_PORT_ui")
    if env and env.isdigit():
        cands.append(int(env))
    cands += [9000, 8327] + list(range(8328, 8336))
    for p in cands:
        if port_free(p):
            return p
    return 0

def main():
    ap = argparse.ArgumentParser(description="tau triad lane resolver + watchdog supervisor")
    ap.add_argument("--scan", action="store_true", help="diagnose lanes/compilers/ports, then exit")
    ap.add_argument("--full-scan", action="store_true", help="also walk the home directory (slower)")
    ap.add_argument("--port", type=int, default=0)
    a = ap.parse_args()

    if a.scan:
        rep = scan(full=a.full_scan)
        print("TAU TRIAD SCAN — " + rep["time"])
        print("here     :", rep["here"])
        for src, hits in rep["sources"].items():
            print(f"{src:<10}", ("FOUND  " + "; ".join(hits)) if hits else "missing")
        for b, hits in rep["binaries"].items():
            print(f"bin {b:<6}", ("FOUND  " + "; ".join(hits)) if hits else "none")
        print("compilers:", ", ".join(f"{k}={v or 'missing'}" for k, v in rep["compilers"].items()))
        print("ports    :", ", ".join(f"{p}={'free' if f else 'busy'}" for p, f in rep["ports"].items()),
              "· NOMAD_PORT_ui=" + (rep["NOMAD_PORT_ui"] or "unset"))
        print("\n→ copy this entire output back into the chat. It says exactly what your disk has.")
        return

    print(f"── tau triad supervisor v{VERSION} · REAL mode ──")
    ensure_lanes(verbose=True)
    threading.Thread(target=watchdog_loop, daemon=True).start()
    threading.Thread(target=tick_loop, daemon=True).start()

    port = pick_port(a.port)
    if not port:
        print("[FAIL] no free port in the cascade")
        sys.exit(1)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    print(f"supervisor → http://127.0.0.1:{port}/")
    if port != 9000:
        print("NOTE: :9000 was busy → cascaded. Your UI auto-detects :9000 only, so")
        print("      kill whatever holds 9000 and rerun for the tabs to flip LIVE.")
    for k, l in STATE.lanes.items():
        s = l.snapshot()
        print(f"lane {k} ({l.name:<6}) " + ("online" if s["state"] == "online" else "offline · " + (s["reason"] or "")))
    print("watchdog: one_for_one · rebuild every 2s · Ctrl+C to stop")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstop → terminating lanes")
        for l in STATE.lanes.values():
            l.stop()

if __name__ == "__main__":
    main()