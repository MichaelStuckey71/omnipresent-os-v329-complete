# OMNIPRESENT OS v3.30-ALL — Validation & Startup

## Status of the supervisor (single canonical copy, v3.30-ALL)

| File | Status | Notes |
|------|--------|-------|
| `omnipresent_os_v330_all.py` | **COMPLETE & COMPILES, boot-verified live** | Dual UI (Classic + Modern), full triad, systems, MPR, watchdog, port cascade. The only copy shipped in this bundle -- no duplicate/twin file. |

## Critical checks already passed

- `python3 -m py_compile omnipresent_os_v330_all.py` → **SYNTAX OK**
- `if __name__ == "__main__": main()` present
- All three lanes (rs / c / py) embedded sources present
- Systems manager, dynamic compression, CAVE-AI, HTTP endpoints intact
- No truncation at end of file

## MPR window note — CORRECTED 2026-09-02

The previous version of this note claimed the live C/Rust/Python supervisor lanes
intentionally kept `WIN = 65535` as the match-search window, and that the
`SRCH=512` cap only lived in the browser-side MPR Lab JS. That claim was checked
by actually running the supervisor and is **wrong**: reverting the search-window
cap in the real lane sources reintroduces a genuine hang/slowdown bug — a 16KB
random (adversarial) payload to `/mpr` took **13.65s** with the uncapped window
in this build, versus ~0.8s with the cap.

`SRCH=512` has been **re-applied** to all three lane sources (C, Rust, embedded
Python) identically, so cross-lane `identical=` output is still byte-for-byte
the same across languages — only the *search* window shrank, not the maximum
encodable distance (`WIN=65535`, used only for the 1-byte-vs-2-byte distance
encoding, is unchanged). Verified live: full fuzz suite (empty/full byte
range/random/repetitive/16KB adversarial) all pass with `identical=True` and
`roundtrip_ok=True`, worst case ~0.8s.

The additive `roundtrip_ok` field on `/mpr` responses (real
`mpr_decompress(mine) == original_sample` check, not just cross-lane hex
agreement) had also been dropped from this build's `triad_mpr()` — restored.

## How to start correctly

```bash
# 1. Run the supervisor (binds 127.0.0.1:9000 or next free port in cascade)
python3 omnipresent_os_v330_all.py

# Optional pin
python3 omnipresent_os_v330_all.py --port 9000
```

Expected console output (abbreviated):

```
v3.29.1-ALL ... ONLINE
[SYSTEMS] detected: ...
[TRIAD] boot cross-check identical=True   (when C + Rust both up)
UI ONLINE: http://127.0.0.1:9000
```

Then open:

- http://127.0.0.1:9000/          → Classic UI
- http://127.0.0.1:9000/modern   → Modern UI

## AI drop-box compatibility

All v3.26 AI surfaces (File Dock, Caveman Dock, 24 free tiles, Omni Summon, keyed providers, Vision Bridge, prompt tying) remain compatible when the full HTML UI is used. The supervisor itself exposes the triad lanes, MPR, systems and CAVE-AI endpoints that the HTML can call when running in live mode.

## If a copy still fails to start

1. Confirm the file ends exactly with:

```python
if __name__ == "__main__":
    main()
```

2. Run `python3 -m py_compile yourfile.py` — must succeed.
3. Prefer the Dual-UI based `omnipresent_os_v330_all.py` delivered here.

No features removed. No architectural deviation. Only completeness + startup correctness.
